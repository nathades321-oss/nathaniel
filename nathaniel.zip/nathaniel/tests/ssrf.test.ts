import { describe, expect, it } from "vitest";
import { AppError } from "@/lib/errors";
import { assertPublicHttpsUrl, assertSafeRemoteUrl, hostMatches, isBlockedHostname, isPrivateAddress } from "@/lib/ssrf";

describe("isPrivateAddress", () => {
  it.each([
    "127.0.0.1", "10.0.0.5", "172.16.4.4", "172.31.255.255", "192.168.1.1", "169.254.169.254",
    "100.64.0.1", "0.0.0.0", "224.0.0.1", "::1", "::", "fe80::1", "fd00::1", "::ffff:127.0.0.1",
  ])("treats %s as private", (address) => {
    expect(isPrivateAddress(address)).toBe(true);
  });

  it.each(["8.8.8.8", "142.250.80.46", "172.32.0.1", "2607:f8b0:4004:c07::71"])("treats %s as public", (address) => {
    expect(isPrivateAddress(address)).toBe(false);
  });

  it("treats non-IP strings as private", () => {
    expect(isPrivateAddress("example.com")).toBe(true);
  });
});

describe("isBlockedHostname", () => {
  it.each(["localhost", "app.localhost", "metadata.google.internal", "printer.local", "intranet", "10.0.0.1", "[::1]"])(
    "blocks %s",
    (host) => expect(isBlockedHostname(host)).toBe(true),
  );

  it("allows ordinary public hostnames", () => {
    expect(isBlockedHostname("www.youtube.com")).toBe(false);
  });
});

describe("hostMatches", () => {
  it("matches exact hosts and subdomains only", () => {
    expect(hostMatches("youtube.com", ["youtube.com"])).toBe(true);
    expect(hostMatches("www.youtube.com", ["youtube.com"])).toBe(true);
    expect(hostMatches("evilyoutube.com", ["youtube.com"])).toBe(false);
    expect(hostMatches("youtube.com.evil.test", ["youtube.com"])).toBe(false);
  });
});

describe("assertPublicHttpsUrl and assertSafeRemoteUrl", () => {
  it("rejects http, credentials, and custom ports", () => {
    expect(() => assertPublicHttpsUrl(new URL("http://www.youtube.com/"))).toThrow(AppError);
    expect(() => assertPublicHttpsUrl(new URL("https://a:b@www.youtube.com/"))).toThrow(AppError);
    expect(() => assertPublicHttpsUrl(new URL("https://www.youtube.com:444/"))).toThrow(AppError);
  });

  it("rejects hosts outside the allowlist before any DNS lookup", async () => {
    await expect(assertSafeRemoteUrl(new URL("https://example.com/file.mp4"), ["cdn.example.net"])).rejects.toMatchObject({
      code: "UNSUPPORTED_URL",
    });
  });

  it("rejects literal private IPs even if allowlisted", async () => {
    await expect(assertSafeRemoteUrl(new URL("https://127.0.0.1/file.mp4"), ["127.0.0.1"])).rejects.toMatchObject({
      code: "UNSUPPORTED_URL",
    });
  });
});
