import { beforeEach, describe, expect, it, vi } from "vitest";
import { AppError } from "@/lib/errors";
import { resetRateLimitsForTests } from "@/lib/rate-limit";

const mocks = vi.hoisted(() => ({
  getOptionalUser: vi.fn(),
  requireApiUser: vi.fn(),
  db: {
    download: { create: vi.fn(), findMany: vi.fn(), deleteMany: vi.fn(), updateMany: vi.fn() },
    downloadEvent: { create: vi.fn() },
    user: { update: vi.fn(), delete: vi.fn() },
  },
  resolveVideo: vi.fn(),
  assertDownloadUrlAllowed: vi.fn(),
}));

vi.mock("@/lib/session", () => ({ getOptionalUser: mocks.getOptionalUser, requireApiUser: mocks.requireApiUser }));
vi.mock("@/lib/db", () => ({ db: mocks.db }));
vi.mock("@/lib/video-service", async () => {
  const actual = await vi.importActual<typeof import("@/lib/video-service")>("@/lib/video-service");
  return { ...actual, resolveVideo: mocks.resolveVideo, assertDownloadUrlAllowed: mocks.assertDownloadUrlAllowed };
});

import { POST as analyze } from "@/app/api/video/analyze/route";
import { POST as download } from "@/app/api/video/download/route";
import { GET as listHistoryRoute } from "@/app/api/history/route";
import { DELETE as deleteHistoryRoute } from "@/app/api/history/[id]/route";

const media = {
  platform: "YOUTUBE" as const,
  sourceUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  title: "Clip",
  author: "Me",
  thumbnailUrl: null,
  durationSeconds: 10,
};

function post(path: string, body: unknown) {
  return new Request(`https://app.test${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-forwarded-for": "198.51.100.1" },
    body: JSON.stringify(body),
  });
}

async function json(response: Response) {
  return (await response.json()) as { success: boolean; data?: any; error?: { code: string; message: string } };
}

beforeEach(() => {
  resetRateLimitsForTests();
  Object.values(mocks.db.download).forEach((fn) => fn.mockReset());
  mocks.db.downloadEvent.create.mockReset().mockResolvedValue({});
  mocks.getOptionalUser.mockReset().mockResolvedValue(null);
  mocks.requireApiUser.mockReset().mockRejectedValue(new AppError("UNAUTHORIZED"));
  mocks.resolveVideo.mockReset();
  mocks.assertDownloadUrlAllowed.mockReset();
});

describe("POST /api/video/analyze", () => {
  it("rejects invalid and unsupported URLs without contacting a provider", async () => {
    const invalid = await analyze(post("/api/video/analyze", { url: "nope" }));
    expect(invalid.status).toBe(400);
    expect((await json(invalid)).error?.code).toBe("INVALID_URL");

    const unsupported = await analyze(post("/api/video/analyze", { url: "https://vimeo.com/1" }));
    expect(unsupported.status).toBe(422);
    expect((await json(unsupported)).error?.code).toBe("UNSUPPORTED_URL");
    expect(mocks.resolveVideo).not.toHaveBeenCalled();
  });

  it("returns the platform restriction notice when no file is offered", async () => {
    mocks.resolveVideo.mockResolvedValue({ provider: {}, media, options: [] });
    const response = await analyze(post("/api/video/analyze", { url: media.sourceUrl }));
    const payload = await json(response);
    expect(response.status).toBe(200);
    expect(payload.data.options).toEqual([]);
    expect(payload.data.notice).toBe("This platform doesn't provide a permitted download option for this video.");
    expect(payload.data.downloadId).toBeNull();
    expect(mocks.db.download.create).not.toHaveBeenCalled();
  });

  it("strips file URLs from options and saves history for signed-in users", async () => {
    mocks.getOptionalUser.mockResolvedValue({ id: "u1", role: "USER" });
    mocks.db.download.create.mockResolvedValue({ id: "d1" });
    mocks.resolveVideo.mockResolvedValue({
      provider: {},
      media,
      options: [{ id: "hd", quality: "1080p", format: "mp4", mimeType: "video/mp4", sizeBytes: 100, url: "https://cdn.test/secret.mp4" }],
    });
    const payload = await json(await analyze(post("/api/video/analyze", { url: media.sourceUrl })));
    expect(payload.data.options).toEqual([{ id: "hd", quality: "1080p", format: "mp4", mimeType: "video/mp4", sizeBytes: 100 }]);
    expect(JSON.stringify(payload)).not.toContain("secret.mp4");
    expect(payload.data.downloadId).toBe("d1");
    expect(mocks.db.download.create.mock.calls[0]?.[0].data).toMatchObject({ userId: "u1", platform: "YOUTUBE", status: "AVAILABLE" });
  });

  it("surfaces provider errors and records a failed event without URLs", async () => {
    mocks.resolveVideo.mockRejectedValue(new AppError("PRIVATE_VIDEO"));
    const response = await analyze(post("/api/video/analyze", { url: media.sourceUrl }));
    expect(response.status).toBe(403);
    const event = mocks.db.downloadEvent.create.mock.calls[0]?.[0].data;
    expect(event).toMatchObject({ platform: "YOUTUBE", success: false, errorCode: "PRIVATE_VIDEO" });
    expect(JSON.stringify(event)).not.toContain("youtube.com/watch");
  });

  it("rate limits anonymous callers", async () => {
    mocks.resolveVideo.mockResolvedValue({ provider: {}, media, options: [] });
    let last: Response | undefined;
    for (let i = 0; i < 11; i += 1) last = await analyze(post("/api/video/analyze", { url: media.sourceUrl }));
    expect(last?.status).toBe(429);
    expect(last?.headers.get("Retry-After")).toBeTruthy();
    expect((await json(last as Response)).error?.code).toBe("RATE_LIMITED");
  });
});

describe("POST /api/video/download", () => {
  const option = { id: "hd", quality: "1080p", format: "mp4", mimeType: "video/mp4", sizeBytes: 5, url: "https://cdn.test/v.mp4" };
  const body = { url: media.sourceUrl, optionId: "hd" };

  beforeEach(() => {
    mocks.resolveVideo.mockResolvedValue({ provider: { downloadHosts: ["cdn.test"] }, media, options: [option] });
    mocks.assertDownloadUrlAllowed.mockResolvedValue(new URL(option.url));
  });

  it("refuses an option the platform did not offer", async () => {
    const response = await download(post("/api/video/download", { ...body, optionId: "missing" }));
    expect(response.status).toBe(422);
    expect((await json(response)).error?.code).toBe("PLATFORM_RESTRICTED");
  });

  it("does not fetch when the file host fails the safety check", async () => {
    mocks.assertDownloadUrlAllowed.mockRejectedValue(new AppError("UNSUPPORTED_URL"));
    const fetchSpy = vi.spyOn(globalThis, "fetch");
    const response = await download(post("/api/video/download", body));
    expect(response.status).toBe(422);
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it("streams the file with attachment headers", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response("hello", { headers: { "content-length": "5" } }));
    const response = await download(post("/api/video/download", body));
    expect(response.status).toBe(200);
    expect(response.headers.get("Content-Disposition")).toBe('attachment; filename="Clip.mp4"');
    expect(await response.text()).toBe("hello");
  });

  it("rejects files whose declared size exceeds the limit", async () => {
    vi.stubEnv("MAX_DOWNLOAD_BYTES", "3");
    vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response("hello", { headers: { "content-length": "5" } }));
    const response = await download(post("/api/video/download", body));
    expect(response.status).toBe(413);
    vi.unstubAllEnvs();
  });

  it("aborts streams that exceed the limit without a declared size", async () => {
    vi.stubEnv("MAX_DOWNLOAD_BYTES", "3");
    vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response("hello world"));
    const response = await download(post("/api/video/download", body));
    await expect(response.text()).rejects.toBeDefined();
    vi.unstubAllEnvs();
  });
});

describe("history authorization", () => {
  it("requires sign in to list history", async () => {
    const response = await listHistoryRoute();
    expect(response.status).toBe(401);
    expect(mocks.db.download.findMany).not.toHaveBeenCalled();
  });

  it("lists only the signed-in user's entries", async () => {
    mocks.requireApiUser.mockResolvedValue({ id: "u1", role: "USER" });
    mocks.db.download.findMany.mockResolvedValue([
      { id: "d1", sourceUrl: "https://youtu.be/x", platform: "YOUTUBE", title: "T", thumbnailUrl: null, status: "AVAILABLE", createdAt: new Date("2026-01-01T00:00:00Z") },
    ]);
    const payload = await json(await listHistoryRoute());
    expect(mocks.db.download.findMany.mock.calls[0]?.[0].where).toEqual({ userId: "u1" });
    expect(payload.data[0]).toMatchObject({ id: "d1", createdAt: "2026-01-01T00:00:00.000Z" });
  });

  it("deletes with ownership in the query and reports NOT_FOUND for other users' entries", async () => {
    mocks.requireApiUser.mockResolvedValue({ id: "u1", role: "USER" });
    mocks.db.download.deleteMany.mockResolvedValueOnce({ count: 1 }).mockResolvedValueOnce({ count: 0 });
    const context = (id: string) => ({ params: Promise.resolve({ id }) });
    const own = await deleteHistoryRoute(new Request("https://app.test", { method: "DELETE" }), context("mine"));
    expect(own.status).toBe(200);
    expect(mocks.db.download.deleteMany).toHaveBeenLastCalledWith({ where: { id: "mine", userId: "u1" } });
    const other = await deleteHistoryRoute(new Request("https://app.test", { method: "DELETE" }), context("theirs"));
    expect(other.status).toBe(404);
  });

  it("requires sign in to delete", async () => {
    const response = await deleteHistoryRoute(new Request("https://app.test", { method: "DELETE" }), { params: Promise.resolve({ id: "x" }) });
    expect(response.status).toBe(401);
    expect(mocks.db.download.deleteMany).not.toHaveBeenCalled();
  });
});
