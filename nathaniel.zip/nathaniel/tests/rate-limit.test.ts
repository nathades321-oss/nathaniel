import { beforeEach, describe, expect, it } from "vitest";
import { enforceRateLimit, getClientIp, rateLimit, resetRateLimitsForTests } from "@/lib/rate-limit";

const rule = { limit: 3, windowSeconds: 60 };

beforeEach(() => resetRateLimitsForTests());

describe("rateLimit", () => {
  it("allows up to the limit then blocks", async () => {
    const results = [];
    for (let i = 0; i < 4; i += 1) results.push(await rateLimit("k", rule));
    expect(results.map((r) => r.allowed)).toEqual([true, true, true, false]);
    expect(results[3]?.retryAfterSeconds).toBeGreaterThan(0);
  });

  it("tracks keys independently", async () => {
    for (let i = 0; i < 4; i += 1) await rateLimit("a", rule);
    expect((await rateLimit("b", rule)).allowed).toBe(true);
  });
});

describe("enforceRateLimit", () => {
  const request = new Request("https://app.test", { headers: { "x-forwarded-for": "203.0.113.9, 10.0.0.1" } });

  it("reads the first forwarded address", () => {
    expect(getClientIp(request)).toBe("203.0.113.9");
  });

  it("throws RATE_LIMITED with Retry-After once exceeded", async () => {
    for (let i = 0; i < 3; i += 1) await enforceRateLimit(request, "scope", null, rule);
    await expect(enforceRateLimit(request, "scope", null, rule)).rejects.toMatchObject({ code: "RATE_LIMITED" });
  });

  it("limits signed-in users by id, not address", async () => {
    for (let i = 0; i < 3; i += 1) await enforceRateLimit(request, "scope", "user-1", rule);
    await expect(enforceRateLimit(request, "scope", "user-2", rule)).resolves.toBeUndefined();
  });
});
