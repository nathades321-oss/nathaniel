import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { TikTokProvider } from "@/lib/providers/tiktok";
import { TwitterProvider } from "@/lib/providers/twitter";
import { InstagramProvider } from "@/lib/providers/instagram";
import { YouTubeProvider, extractYouTubeId, parseIsoDuration } from "@/lib/providers/youtube";

function mockFetchOnce(body: unknown, status = 200) {
  const spy = vi.spyOn(globalThis, "fetch").mockResolvedValue(
    new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } }),
  );
  return spy;
}

beforeEach(() => {
  vi.stubEnv("YOUTUBE_API_KEY", "");
  vi.stubEnv("META_APP_ID", "");
  vi.stubEnv("META_CLIENT_TOKEN", "");
});

afterEach(() => vi.unstubAllEnvs());

describe("TikTokProvider", () => {
  const url = new URL("https://www.tiktok.com/@someone/video/7234567890123456789");

  it("maps oEmbed metadata and offers no file", async () => {
    const spy = mockFetchOnce({ title: "Dance", author_name: "someone", thumbnail_url: "https://p16.example.com/t.jpg" });
    const provider = new TikTokProvider();
    const media = await provider.getMediaInfo(url);
    expect(media).toMatchObject({ platform: "TIKTOK", title: "Dance", author: "someone", thumbnailUrl: "https://p16.example.com/t.jpg" });
    expect(await provider.getDownloadOptions(media)).toEqual([]);
    const called = new URL(String((spy.mock.calls[0] as [URL])[0]));
    expect(called.host).toBe("www.tiktok.com");
    expect(called.searchParams.get("url")).toBe(url.toString());
  });

  it("maps 404 to PRIVATE_VIDEO and 500 to NETWORK_ERROR", async () => {
    mockFetchOnce({}, 404);
    await expect(new TikTokProvider().getMediaInfo(url)).rejects.toMatchObject({ code: "PRIVATE_VIDEO" });
    mockFetchOnce({}, 500);
    await expect(new TikTokProvider().getMediaInfo(url)).rejects.toMatchObject({ code: "NETWORK_ERROR" });
  });

  it("maps a thrown fetch to NETWORK_ERROR", async () => {
    vi.spyOn(globalThis, "fetch").mockRejectedValue(new TypeError("offline"));
    await expect(new TikTokProvider().getMediaInfo(url)).rejects.toMatchObject({ code: "NETWORK_ERROR" });
  });

  it("drops non-https thumbnails", async () => {
    mockFetchOnce({ title: "x", thumbnail_url: "http://insecure.test/t.jpg" });
    expect((await new TikTokProvider().getMediaInfo(url)).thumbnailUrl).toBeNull();
  });
});

describe("TwitterProvider", () => {
  it("uses the post text as the title", async () => {
    mockFetchOnce({ author_name: "Ada", html: '<blockquote><p lang="en">Hello &amp; welcome<br>friends</p></blockquote>' });
    const media = await new TwitterProvider().getMediaInfo(new URL("https://x.com/ada/status/123"));
    expect(media.title).toBe("Hello & welcomefriends");
    expect(media.author).toBe("Ada");
  });
});

describe("credentialed providers", () => {
  it("report missing configuration and refuse to call the platform", async () => {
    const spy = vi.spyOn(globalThis, "fetch");
    const youtube = new YouTubeProvider();
    expect(youtube.getStatus()).toEqual({ configured: false, requiredEnv: ["YOUTUBE_API_KEY"] });
    await expect(youtube.getMediaInfo(new URL("https://youtu.be/dQw4w9WgXcQ"))).rejects.toMatchObject({ code: "PROVIDER_UNAVAILABLE" });
    const instagram = new InstagramProvider();
    expect(instagram.getStatus().configured).toBe(false);
    await expect(instagram.getMediaInfo(new URL("https://www.instagram.com/reel/abc123/"))).rejects.toMatchObject({ code: "PROVIDER_UNAVAILABLE" });
    expect(spy).not.toHaveBeenCalled();
  });

  it("YouTube maps the Data API response", async () => {
    vi.stubEnv("YOUTUBE_API_KEY", "test-key");
    mockFetchOnce({
      items: [
        {
          snippet: { title: "Song", channelTitle: "Channel", thumbnails: { high: { url: "https://i.ytimg.com/h.jpg" } } },
          contentDetails: { duration: "PT1M5S" },
          status: { privacyStatus: "public" },
        },
      ],
    });
    const media = await new YouTubeProvider().getMediaInfo(new URL("https://youtu.be/dQw4w9WgXcQ"));
    expect(media).toMatchObject({ title: "Song", author: "Channel", durationSeconds: 65, thumbnailUrl: "https://i.ytimg.com/h.jpg" });
    expect(media.sourceUrl).toBe("https://www.youtube.com/watch?v=dQw4w9WgXcQ");
  });

  it("YouTube reports missing or private videos as PRIVATE_VIDEO", async () => {
    vi.stubEnv("YOUTUBE_API_KEY", "test-key");
    mockFetchOnce({ items: [] });
    await expect(new YouTubeProvider().getMediaInfo(new URL("https://youtu.be/dQw4w9WgXcQ"))).rejects.toMatchObject({ code: "PRIVATE_VIDEO" });
  });
});

describe("YouTube helpers", () => {
  it("parses ISO 8601 durations", () => {
    expect(parseIsoDuration("PT42S")).toBe(42);
    expect(parseIsoDuration("PT1H2M3S")).toBe(3723);
    expect(parseIsoDuration("P1DT1S")).toBe(86_401);
    expect(parseIsoDuration("nonsense")).toBeNull();
  });

  it("extracts video ids from supported shapes only", () => {
    expect(extractYouTubeId(new URL("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))).toBe("dQw4w9WgXcQ");
    expect(extractYouTubeId(new URL("https://youtu.be/dQw4w9WgXcQ?t=5"))).toBe("dQw4w9WgXcQ");
    expect(extractYouTubeId(new URL("https://www.youtube.com/shorts/dQw4w9WgXcQ"))).toBe("dQw4w9WgXcQ");
    expect(extractYouTubeId(new URL("https://www.youtube.com/watch?v=short"))).toBeNull();
    expect(extractYouTubeId(new URL("https://www.youtube.com/playlist?list=abc"))).toBeNull();
  });
});
