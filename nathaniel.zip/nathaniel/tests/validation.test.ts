import { describe, expect, it } from "vitest";
import { videoUrlSchema } from "@/lib/validation";
import { detectPlatform, findProvider, getProviderByPlatform, listProviders } from "@/lib/providers/registry";

function errorCode(input: unknown): string | undefined {
  const result = videoUrlSchema.safeParse(input);
  if (result.success) return undefined;
  const issue = result.error.issues[0] as { params?: { appCode?: string } } | undefined;
  return issue?.params?.appCode ?? "VALIDATION_ERROR";
}

describe("videoUrlSchema", () => {
  it.each([
    "https://www.tiktok.com/@someone/video/7234567890123456789",
    "https://x.com/someone/status/1234567890",
    "https://twitter.com/someone/status/1234567890?s=20",
    "https://www.instagram.com/reel/C1a2B3c4D5e/",
    "https://www.facebook.com/someone/videos/123456789",
    "https://fb.watch/abc123/",
    "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    "https://youtu.be/dQw4w9WgXcQ",
    "https://www.youtube.com/shorts/dQw4w9WgXcQ",
  ])("accepts %s", (input) => {
    expect(videoUrlSchema.safeParse(input).success).toBe(true);
  });

  it("trims whitespace and upgrades http to https", () => {
    const result = videoUrlSchema.parse("  http://youtu.be/dQw4w9WgXcQ  ");
    expect(result.protocol).toBe("https:");
  });

  it("rejects empty and non-string input", () => {
    expect(errorCode("")).toBe("VALIDATION_ERROR");
    expect(errorCode("   ")).toBe("VALIDATION_ERROR");
    expect(errorCode(undefined)).toBe("VALIDATION_ERROR");
    expect(errorCode(42)).toBe("VALIDATION_ERROR");
  });

  it("rejects malformed URLs", () => {
    expect(errorCode("not a url")).toBe("INVALID_URL");
    expect(errorCode("https://")).toBe("INVALID_URL");
  });

  it("rejects non-http schemes", () => {
    expect(errorCode("javascript:alert(1)")).toBe("INVALID_URL");
    expect(errorCode("ftp://youtube.com/watch?v=dQw4w9WgXcQ")).toBe("INVALID_URL");
    expect(errorCode("file:///etc/passwd")).toBe("INVALID_URL");
  });

  it("rejects unsupported domains", () => {
    expect(errorCode("https://example.com/video/1")).toBe("UNSUPPORTED_URL");
    expect(errorCode("https://vimeo.com/123456")).toBe("UNSUPPORTED_URL");
  });

  it("rejects lookalike domains", () => {
    expect(errorCode("https://youtube.com.evil.test/watch?v=dQw4w9WgXcQ")).toBe("UNSUPPORTED_URL");
    expect(errorCode("https://notyoutube.com/watch?v=dQw4w9WgXcQ")).toBe("UNSUPPORTED_URL");
  });

  it("rejects supported domains with an unrecognised path", () => {
    expect(errorCode("https://www.youtube.com/")).toBe("INVALID_URL");
    expect(errorCode("https://www.tiktok.com/@someone")).toBe("INVALID_URL");
    expect(errorCode("https://x.com/someone")).toBe("INVALID_URL");
  });

  it("rejects internal addresses, credentials, and odd ports", () => {
    expect(errorCode("https://localhost/watch?v=dQw4w9WgXcQ")).toBe("UNSUPPORTED_URL");
    expect(errorCode("https://127.0.0.1/")).toBe("UNSUPPORTED_URL");
    expect(errorCode("https://169.254.169.254/latest/meta-data/")).toBe("UNSUPPORTED_URL");
    expect(errorCode("https://user:pass@www.youtube.com/watch?v=dQw4w9WgXcQ")).toBe("INVALID_URL");
    expect(errorCode("https://www.youtube.com:8443/watch?v=dQw4w9WgXcQ")).toBe("INVALID_URL");
  });

  it("rejects overly long input", () => {
    expect(errorCode(`https://www.youtube.com/watch?v=dQw4w9WgXcQ&x=${"a".repeat(3000)}`)).toBe("VALIDATION_ERROR");
  });
});

describe("platform detection and provider selection", () => {
  it.each([
    ["https://www.tiktok.com/@a/video/1", "TIKTOK"],
    ["https://x.com/a/status/1", "TWITTER"],
    ["https://twitter.com/a/status/1", "TWITTER"],
    ["https://www.instagram.com/p/abc123/", "INSTAGRAM"],
    ["https://www.facebook.com/watch/?v=123", "FACEBOOK"],
    ["https://fb.watch/abc/", "FACEBOOK"],
    ["https://m.youtube.com/watch?v=dQw4w9WgXcQ", "YOUTUBE"],
  ])("maps %s to %s", (input, platform) => {
    const url = new URL(input);
    expect(detectPlatform(url)).toBe(platform);
    expect(findProvider(url)?.platform).toBe(platform);
  });

  it("returns null for unknown hosts", () => {
    expect(detectPlatform(new URL("https://example.com/"))).toBeNull();
    expect(findProvider(new URL("https://example.com/"))).toBeNull();
  });

  it("registers exactly one provider per platform", () => {
    const platforms = listProviders().map((provider) => provider.platform);
    expect(new Set(platforms).size).toBe(platforms.length);
    for (const platform of platforms) expect(getProviderByPlatform(platform)?.platform).toBe(platform);
  });

  it("never offers downloads by default", async () => {
    for (const provider of listProviders()) {
      const options = await provider.getDownloadOptions({
        platform: provider.platform,
        sourceUrl: "https://example.test",
        title: "t",
        author: null,
        thumbnailUrl: null,
        durationSeconds: null,
      });
      expect(options).toEqual([]);
    }
  });
});
