import { describe, expect, it, vi } from "vitest";
import { z } from "zod";
import { fail, ok, parseJson, withErrorHandling } from "@/lib/api";
import { AppError, ERROR_MESSAGES } from "@/lib/errors";
import { videoUrlSchema } from "@/lib/validation";

async function body(response: Response) {
  return (await response.json()) as { success: boolean; data?: unknown; error?: { code: string; message: string } };
}

describe("response envelope", () => {
  it("wraps success data", async () => {
    expect(await body(ok({ a: 1 }))).toEqual({ success: true, data: { a: 1 } });
  });

  it("wraps errors with the mapped status and message", async () => {
    const response = fail("RATE_LIMITED", undefined, 12);
    expect(response.status).toBe(429);
    expect(response.headers.get("Retry-After")).toBe("12");
    expect(await body(response)).toEqual({
      success: false,
      error: { code: "RATE_LIMITED", message: ERROR_MESSAGES.RATE_LIMITED },
    });
  });
});

describe("withErrorHandling", () => {
  it("passes through successful responses", async () => {
    const response = await withErrorHandling(async () => ok({ fine: true }));
    expect(response.status).toBe(200);
  });

  it("maps AppError to its code", async () => {
    const response = await withErrorHandling(async () => {
      throw new AppError("PRIVATE_VIDEO");
    });
    expect(response.status).toBe(403);
    expect((await body(response)).error?.code).toBe("PRIVATE_VIDEO");
  });

  it("maps URL validation failures to specific codes", async () => {
    const response = await withErrorHandling(async () => {
      videoUrlSchema.parse("https://example.com/x");
      return ok({});
    });
    const payload = await body(response);
    expect(response.status).toBe(422);
    expect(payload.error).toEqual({ code: "UNSUPPORTED_URL", message: ERROR_MESSAGES.UNSUPPORTED_URL });
  });

  it("maps generic validation failures to VALIDATION_ERROR", async () => {
    const response = await withErrorHandling(async () => {
      z.object({ a: z.string() }).parse({});
      return ok({});
    });
    expect(response.status).toBe(400);
    expect((await body(response)).error?.code).toBe("VALIDATION_ERROR");
  });

  it("hides internal error details", async () => {
    vi.spyOn(console, "error").mockImplementation(() => undefined);
    const response = await withErrorHandling(async () => {
      throw new Error("database password is hunter2 at /srv/app/db.ts:12");
    });
    const text = JSON.stringify(await body(response));
    expect(response.status).toBe(500);
    expect(text).not.toContain("hunter2");
    expect(text).not.toContain("/srv/app");
    expect(text).toContain("INTERNAL_ERROR");
  });
});

describe("parseJson", () => {
  const schema = z.object({ a: z.number() });

  it("parses valid JSON", async () => {
    const request = new Request("https://app.test", { method: "POST", body: JSON.stringify({ a: 1 }) });
    await expect(parseJson(request, schema)).resolves.toEqual({ a: 1 });
  });

  it("rejects invalid JSON and oversized bodies", async () => {
    await expect(parseJson(new Request("https://app.test", { method: "POST", body: "{" }), schema)).rejects.toBeInstanceOf(AppError);
    const big = JSON.stringify({ a: 1, pad: "x".repeat(20_000) });
    await expect(parseJson(new Request("https://app.test", { method: "POST", body: big }), schema)).rejects.toBeInstanceOf(AppError);
  });
});
