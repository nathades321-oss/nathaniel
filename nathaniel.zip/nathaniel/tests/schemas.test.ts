import { describe, expect, it } from "vitest";
import { analyzeRequestSchema, downloadRequestSchema, loginSchema, registerSchema, settingsSchema } from "@/lib/validation";

describe("request schemas", () => {
  it("analyze requires a valid url and rejects extra keys", () => {
    expect(analyzeRequestSchema.safeParse({ url: "https://youtu.be/dQw4w9WgXcQ" }).success).toBe(true);
    expect(analyzeRequestSchema.safeParse({}).success).toBe(false);
    expect(analyzeRequestSchema.safeParse({ url: "https://youtu.be/dQw4w9WgXcQ", extra: 1 }).success).toBe(false);
  });

  it("download requires an option id and never accepts a file url", () => {
    const base = { url: "https://youtu.be/dQw4w9WgXcQ", optionId: "hd" };
    expect(downloadRequestSchema.safeParse(base).success).toBe(true);
    expect(downloadRequestSchema.safeParse({ url: base.url }).success).toBe(false);
    expect(downloadRequestSchema.safeParse({ ...base, fileUrl: "https://evil.test/x.mp4" }).success).toBe(false);
  });

  it("register normalises email and enforces password rules", () => {
    const parsed = registerSchema.parse({ name: " Ada ", email: " ADA@Example.COM ", password: "longenough1" });
    expect(parsed).toEqual({ name: "Ada", email: "ada@example.com", password: "longenough1" });
    expect(registerSchema.safeParse({ name: "A", email: "a@b.co", password: "short1" }).success).toBe(false);
    expect(registerSchema.safeParse({ name: "A", email: "a@b.co", password: "noDigitsHere" }).success).toBe(false);
    expect(registerSchema.safeParse({ name: "A", email: "a@b.co", password: "1234567890" }).success).toBe(false);
    expect(registerSchema.safeParse({ name: "A", email: "nope", password: "longenough1" }).success).toBe(false);
  });

  it("login and settings validate their inputs", () => {
    expect(loginSchema.safeParse({ email: "a@b.co", password: "x" }).success).toBe(true);
    expect(loginSchema.safeParse({ email: "bad", password: "x" }).success).toBe(false);
    expect(settingsSchema.safeParse({ name: "   " }).success).toBe(false);
  });
});
