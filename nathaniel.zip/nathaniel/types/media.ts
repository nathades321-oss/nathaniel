export type Platform = "TIKTOK" | "TWITTER" | "INSTAGRAM" | "FACEBOOK" | "YOUTUBE";

export interface MediaInfo {
  platform: Platform;
  sourceUrl: string;
  title: string;
  author: string | null;
  thumbnailUrl: string | null;
  durationSeconds: number | null;
}

/** Server-side option. `url` is the file location and never leaves the server. */
export interface DownloadOption {
  id: string;
  quality: string;
  format: string;
  mimeType: string;
  sizeBytes: number | null;
  url: string;
}

export type PublicDownloadOption = Omit<DownloadOption, "url">;

export interface ProviderStatus {
  configured: boolean;
  requiredEnv: string[];
}
