import type { MediaInfo, PublicDownloadOption } from "@/types/media";

export interface ApiSuccess<T> {
  success: true;
  data: T;
}

export interface ApiFailure {
  success: false;
  error: { code: string; message: string };
}

export type ApiResponse<T> = ApiSuccess<T> | ApiFailure;

export interface AnalyzeData {
  media: MediaInfo;
  options: PublicDownloadOption[];
  downloadId: string | null;
  notice: string | null;
}

export interface HistoryEntry {
  id: string;
  sourceUrl: string;
  platform: string;
  title: string;
  thumbnailUrl: string | null;
  status: "AVAILABLE" | "UNAVAILABLE" | "DOWNLOADED" | "FAILED";
  createdAt: string;
}
