import bcrypt from "bcryptjs";
import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { db } from "@/lib/db";
import { rateLimit, hashIdentifier } from "@/lib/rate-limit";
import { loginSchema } from "@/lib/validation";

/** Used to keep response time similar when the email does not exist. */
const DUMMY_HASH = "$2a$12$C6UzMDM.H6dfI/f/IKcEeO5aQe8gZ0yB3dQ1m0o7cQeVQ9YF6O3oa";

export const { handlers, auth, signIn, signOut } = NextAuth({
  session: { strategy: "jwt", maxAge: 60 * 60 * 24 * 14 },
  pages: { signIn: "/login" },
  trustHost: process.env.AUTH_TRUST_HOST === "true" || process.env.VERCEL === "1",
  providers: [
    Credentials({
      credentials: { email: {}, password: {} },
      async authorize(raw) {
        const parsed = loginSchema.safeParse(raw);
        if (!parsed.success) return null;
        const { email, password } = parsed.data;

        const attempts = await rateLimit(`login:${hashIdentifier(email)}`, { limit: 10, windowSeconds: 15 * 60 });
        if (!attempts.allowed) return null;

        const user = await db.user.findUnique({ where: { email } });
        const valid = await bcrypt.compare(password, user?.passwordHash ?? DUMMY_HASH);
        if (!user || !valid) return null;

        return { id: user.id, name: user.name, email: user.email, image: user.image, role: user.role };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user?.id) token.id = user.id;
      const id = token.id ?? token.sub;
      if (!id) return null;
      const current = await db.user.findUnique({ where: { id }, select: { id: true, role: true } });
      if (!current) return null;
      token.id = current.id;
      token.role = current.role;
      return token;
    },
    session({ session, token }) {
      if (token.id) session.user.id = token.id;
      session.user.role = token.role ?? "USER";
      return session;
    },
  },
});
