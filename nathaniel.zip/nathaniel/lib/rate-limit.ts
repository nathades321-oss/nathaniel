import { createHash } from "node:crypto";
import { AppError } from "@/lib/errors";

export interface RateLimitRule {
  limit: number;
  windowSeconds: number;
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  retryAfterSeconds: number;
}

interface Bucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();
const MAX_BUCKETS = 10_000;

function memoryLimit(key: string, rule: RateLimitRule): RateLimitResult {
  const now = Date.now();
  if (buckets.size > MAX_BUCKETS) {
    for (const [bucketKey, bucket] of buckets) {
      if (bucket.resetAt <= now) buckets.delete(bucketKey);
    }
  }
  const existing = buckets.get(key);
  const bucket = existing && existing.resetAt > now ? existing : { count: 0, resetAt: now + rule.windowSeconds * 1000 };
  bucket.count += 1;
  buckets.set(key, bucket);
  return {
    allowed: bucket.count <= rule.limit,
    remaining: Math.max(0, rule.limit - bucket.count),
    retryAfterSeconds: Math.max(1, Math.ceil((bucket.resetAt - now) / 1000)),
  };
}

async function upstashLimit(key: string, rule: RateLimitRule): Promise<RateLimitResult | null> {
  const url = process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.UPSTASH_REDIS_REST_TOKEN;
  if (!url || !token) return null;
  try {
    const response = await fetch(`${url}/pipeline`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify([
        ["INCR", key],
        ["EXPIRE", key, rule.windowSeconds, "NX"],
        ["TTL", key],
      ]),
      signal: AbortSignal.timeout(2000),
      cache: "no-store",
    });
    if (!response.ok) return null;
    const results = (await response.json()) as Array<{ result?: number }>;
    const count = results[0]?.result;
    const ttl = results[2]?.result;
    if (typeof count !== "number") return null;
    return {
      allowed: count <= rule.limit,
      remaining: Math.max(0, rule.limit - count),
      retryAfterSeconds: typeof ttl === "number" && ttl > 0 ? ttl : rule.windowSeconds,
    };
  } catch {
    return null;
  }
}

export async function rateLimit(key: string, rule: RateLimitRule): Promise<RateLimitResult> {
  const remote = await upstashLimit(`nathaniel:${key}`, rule);
  return remote ?? memoryLimit(key, rule);
}

export function hashIdentifier(value: string): string {
  return createHash("sha256").update(value).digest("hex").slice(0, 32);
}

export function getClientIp(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  return forwarded || request.headers.get("x-real-ip") || "unknown";
}

/** Throws RATE_LIMITED when the caller exceeds the rule. Keys use hashed identifiers only. */
export async function enforceRateLimit(
  request: Request,
  scope: string,
  userId: string | null | undefined,
  rule: RateLimitRule,
): Promise<void> {
  const identity = userId ? `u:${userId}` : `ip:${getClientIp(request)}`;
  const result = await rateLimit(`${scope}:${hashIdentifier(identity)}`, rule);
  if (!result.allowed) {
    throw new AppError("RATE_LIMITED", undefined, { retryAfterSeconds: result.retryAfterSeconds });
  }
}

export function resetRateLimitsForTests(): void {
  buckets.clear();
}
