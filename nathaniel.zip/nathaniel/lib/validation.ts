import { z } from "zod";
import { ERROR_MESSAGES, type ErrorCode } from "@/lib/errors";
import { detectPlatform, findProvider } from "@/lib/providers/registry";
import { assertPublicHttpsUrl } from "@/lib/ssrf";
import { AppError } from "@/lib/errors";

export const MAX_URL_LENGTH = 2048;

function issue(ctx: z.RefinementCtx, code: ErrorCode): typeof z.NEVER {
  ctx.addIssue({ code: z.ZodIssueCode.custom, message: ERROR_MESSAGES[code], params: { appCode: code } });
  return z.NEVER;
}

/**
 * Parses and validates a user-supplied video URL. The output is a normalised
 * HTTPS URL that a registered provider recognises. Nothing is fetched here.
 */
export const videoUrlSchema = z
  .string({ required_error: ERROR_MESSAGES.INVALID_URL, invalid_type_error: ERROR_MESSAGES.INVALID_URL })
  .trim()
  .min(1, ERROR_MESSAGES.INVALID_URL)
  .max(MAX_URL_LENGTH, ERROR_MESSAGES.INVALID_URL)
  .transform((value, ctx): URL => {
    let url: URL;
    try {
      url = new URL(value);
    } catch {
      return issue(ctx, "INVALID_URL");
    }
    if (url.protocol === "http:") url.protocol = "https:";
    url.hash = "";
    try {
      assertPublicHttpsUrl(url);
    } catch (error) {
      return issue(ctx, error instanceof AppError ? error.code : "INVALID_URL");
    }
    if (detectPlatform(url) === null) return issue(ctx, "UNSUPPORTED_URL");
    if (findProvider(url) === null) return issue(ctx, "INVALID_URL");
    return url;
  });

export const analyzeRequestSchema = z.object({ url: videoUrlSchema }).strict();

export const downloadRequestSchema = z
  .object({
    url: videoUrlSchema,
    optionId: z.string().min(1).max(100),
    downloadId: z.string().min(1).max(64).optional(),
  })
  .strict();

export const registerSchema = z
  .object({
    name: z.string().trim().min(1, "Enter your name.").max(80),
    email: z.string().trim().toLowerCase().email("Enter a valid email address.").max(254),
    password: z
      .string()
      .min(10, "Use at least 10 characters.")
      .max(72, "Use 72 characters or fewer.")
      .regex(/[A-Za-z]/, "Include at least one letter.")
      .regex(/\d/, "Include at least one number."),
  })
  .strict();

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email().max(254),
  password: z.string().min(1).max(72),
});

export const settingsSchema = z.object({ name: z.string().trim().min(1, "Enter your name.").max(80) }).strict();

export const historyIdSchema = z.string().min(1).max(64);

export type AnalyzeRequest = z.output<typeof analyzeRequestSchema>;
export type DownloadRequest = z.output<typeof downloadRequestSchema>;
