import type { Platform } from "@/types/media";

export const PLATFORMS: readonly Platform[] = ["TIKTOK", "TWITTER", "INSTAGRAM", "FACEBOOK", "YOUTUBE"];

export const PLATFORM_LABELS: Record<Platform, string> = {
  TIKTOK: "TikTok",
  TWITTER: "X / Twitter",
  INSTAGRAM: "Instagram",
  FACEBOOK: "Facebook",
  YOUTUBE: "YouTube",
};

export function platformLabel(value: string): string {
  return PLATFORM_LABELS[value as Platform] ?? value;
}
