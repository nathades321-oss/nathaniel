import { NextResponse } from "next/server";
import { ZodError, type ZodTypeAny, type z } from "zod";
import { AppError, ERROR_MESSAGES, ERROR_STATUS, isErrorCode, type ErrorCode } from "@/lib/errors";
import type { ApiFailure, ApiSuccess } from "@/types/api";

const MAX_BODY_BYTES = 10_000;

export function ok<T>(data: T, init?: ResponseInit): NextResponse<ApiSuccess<T>> {
  return NextResponse.json({ success: true as const, data }, init);
}

export function fail(code: ErrorCode, message?: string, retryAfterSeconds?: number): NextResponse<ApiFailure> {
  const headers: Record<string, string> = {};
  if (retryAfterSeconds !== undefined) headers["Retry-After"] = String(retryAfterSeconds);
  return NextResponse.json(
    { success: false as const, error: { code, message: message ?? ERROR_MESSAGES[code] } },
    { status: ERROR_STATUS[code], headers },
  );
}

function fromZodError(error: ZodError): AppError {
  const issue = error.issues[0];
  const params = issue && "params" in issue ? (issue.params as { appCode?: unknown } | undefined) : undefined;
  const code = isErrorCode(params?.appCode) ? params.appCode : "VALIDATION_ERROR";
  return new AppError(code, code === "VALIDATION_ERROR" ? (issue?.message ?? ERROR_MESSAGES[code]) : undefined);
}

/** Runs a handler and converts every failure into the consistent error envelope. */
export async function withErrorHandling(handler: () => Promise<Response>): Promise<Response> {
  try {
    return await handler();
  } catch (error) {
    if (error instanceof AppError) return fail(error.code, error.message, error.retryAfterSeconds);
    if (error instanceof ZodError) {
      const appError = fromZodError(error);
      return fail(appError.code, appError.message);
    }
    console.error("Unhandled API error", error instanceof Error ? error.name : "unknown");
    return fail("INTERNAL_ERROR");
  }
}

/** Reads a small JSON body and validates it. Throws AppError/ZodError on failure. */
export async function parseJson<S extends ZodTypeAny>(request: Request, schema: S): Promise<z.output<S>> {
  const text = await request.text();
  if (text.length > MAX_BODY_BYTES) throw new AppError("VALIDATION_ERROR", "The request is too large.");
  let body: unknown;
  try {
    body = JSON.parse(text);
  } catch {
    throw new AppError("VALIDATION_ERROR", "The request body must be valid JSON.");
  }
  return schema.parse(body);
}
