import { lookup } from "node:dns/promises";
import { isIP } from "node:net";
import { AppError } from "@/lib/errors";

const BLOCKED_SUFFIXES = [".localhost", ".local", ".internal", ".lan", ".home", ".corp", ".intranet"];

export function hostMatches(hostname: string, domains: readonly string[]): boolean {
  const host = hostname.toLowerCase().replace(/\.$/, "");
  return domains.some((domain) => host === domain || host.endsWith(`.${domain}`));
}

function isPrivateIpv4(address: string): boolean {
  const parts = address.split(".").map(Number);
  const [a = 0, b = 0, c = 0] = parts;
  if (parts.length !== 4 || parts.some((part) => Number.isNaN(part))) return true;
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 100 && b >= 64 && b <= 127) ||
    (a === 169 && b === 254) ||
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 0 && c === 0) ||
    (a === 192 && b === 168) ||
    (a === 198 && (b === 18 || b === 19)) ||
    a >= 224
  );
}

function isPrivateIpv6(address: string): boolean {
  const value = address.toLowerCase();
  return (
    value === "::" ||
    value === "::1" ||
    value.startsWith("::ffff:") ||
    value.startsWith("64:ff9b:") ||
    value.startsWith("fc") ||
    value.startsWith("fd") ||
    /^fe[89ab]/.test(value) ||
    value.startsWith("ff")
  );
}

/** True for loopback, private, link-local (including cloud metadata), CGNAT, and reserved ranges. */
export function isPrivateAddress(address: string): boolean {
  const version = isIP(address);
  if (version === 4) return isPrivateIpv4(address);
  if (version === 6) return isPrivateIpv6(address);
  return true;
}

export function isBlockedHostname(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/\.$/, "");
  if (!host || !host.includes(".")) return true;
  if (host === "localhost" || host === "metadata.google.internal") return true;
  if (isIP(host.replace(/^\[|\]$/g, "")) !== 0) return true;
  return BLOCKED_SUFFIXES.some((suffix) => host.endsWith(suffix));
}

/** Synchronous checks shared by user-supplied URLs and provider-supplied file URLs. */
export function assertPublicHttpsUrl(url: URL): void {
  if (url.protocol !== "https:") throw new AppError("INVALID_URL");
  if (url.username || url.password) throw new AppError("INVALID_URL");
  if (url.port && url.port !== "443") throw new AppError("INVALID_URL");
  if (isBlockedHostname(url.hostname)) throw new AppError("UNSUPPORTED_URL");
}

/**
 * Full check for URLs the server is about to fetch: HTTPS, allowlisted host,
 * and every DNS answer must be a public address.
 */
export async function assertSafeRemoteUrl(url: URL, allowedHosts: readonly string[]): Promise<void> {
  assertPublicHttpsUrl(url);
  if (!hostMatches(url.hostname, allowedHosts)) throw new AppError("UNSUPPORTED_URL");
  let addresses: Array<{ address: string }>;
  try {
    addresses = await lookup(url.hostname, { all: true });
  } catch {
    throw new AppError("NETWORK_ERROR");
  }
  if (addresses.length === 0 || addresses.some(({ address }) => isPrivateAddress(address))) {
    throw new AppError("UNSUPPORTED_URL");
  }
}
