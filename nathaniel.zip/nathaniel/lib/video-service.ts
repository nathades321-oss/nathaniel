import { AppError } from "@/lib/errors";
import { findProvider } from "@/lib/providers/registry";
import type { DownloadOption, MediaInfo } from "@/lib/providers/types";
import type { ProviderResult, VideoProvider } from "@/lib/providers/types";
import { assertSafeRemoteUrl } from "@/lib/ssrf";
import type { PublicDownloadOption } from "@/types/media";

export function toPublicOption(option: DownloadOption): PublicDownloadOption {
  return {
    id: option.id,
    quality: option.quality,
    format: option.format,
    mimeType: option.mimeType,
    sizeBytes: option.sizeBytes,
  };
}

export function selectProvider(url: URL): VideoProvider {
  const provider = findProvider(url);
  if (!provider) throw new AppError("UNSUPPORTED_URL");
  return provider;
}

/** Resolves media information and the download options the platform permits. */
export async function resolveVideo(url: URL): Promise<{ provider: VideoProvider; media: MediaInfo; options: DownloadOption[] }> {
  const provider = selectProvider(url);
  if (!provider.getStatus().configured) throw new AppError("PROVIDER_UNAVAILABLE");
  const media = await provider.getMediaInfo(url);
  const options = await provider.getDownloadOptions(media);
  return { provider, media, options };
}

export async function resolveVideoSafely(url: URL): Promise<ProviderResult> {
  try {
    const { media, options } = await resolveVideo(url);
    return { ok: true, media, options };
  } catch (error) {
    if (error instanceof AppError) return { ok: false, error: { code: error.code, message: error.message } };
    throw error;
  }
}

/** Confirms a provider-supplied file URL is HTTPS, on the provider's allowlist, and resolves to public addresses. */
export async function assertDownloadUrlAllowed(provider: VideoProvider, option: DownloadOption): Promise<URL> {
  let fileUrl: URL;
  try {
    fileUrl = new URL(option.url);
  } catch {
    throw new AppError("PLATFORM_RESTRICTED");
  }
  await assertSafeRemoteUrl(fileUrl, provider.downloadHosts);
  return fileUrl;
}
