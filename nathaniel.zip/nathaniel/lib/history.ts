import { db } from "@/lib/db";
import { AppError } from "@/lib/errors";
import type { HistoryEntry } from "@/types/api";

const HISTORY_LIMIT = 200;

function toEntry(row: {
  id: string;
  sourceUrl: string;
  platform: string;
  title: string;
  thumbnailUrl: string | null;
  status: HistoryEntry["status"];
  createdAt: Date;
}): HistoryEntry {
  return { ...row, createdAt: row.createdAt.toISOString() };
}

export async function listHistory(userId: string): Promise<HistoryEntry[]> {
  const rows = await db.download.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    take: HISTORY_LIMIT,
    select: { id: true, sourceUrl: true, platform: true, title: true, thumbnailUrl: true, status: true, createdAt: true },
  });
  return rows.map(toEntry);
}

/** Deletes one entry. Ownership is part of the query, so other users' entries look like NOT_FOUND. */
export async function deleteHistoryEntry(userId: string, id: string): Promise<void> {
  const result = await db.download.deleteMany({ where: { id, userId } });
  if (result.count === 0) throw new AppError("NOT_FOUND");
}

export async function markDownloadStatus(
  userId: string,
  id: string,
  status: "DOWNLOADED" | "FAILED",
): Promise<void> {
  await db.download.updateMany({ where: { id, userId }, data: { status } });
}
