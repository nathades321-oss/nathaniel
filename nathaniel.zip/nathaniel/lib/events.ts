import { db } from "@/lib/db";

interface EventInput {
  type: "ANALYZE" | "DOWNLOAD";
  platform: string;
  success: boolean;
  errorCode?: string | null;
  durationMs: number;
  downloadId?: string | null;
}

/** Records operational telemetry. Never stores URLs, IPs, or user identifiers. Failures are swallowed. */
export async function recordEvent(input: EventInput): Promise<void> {
  try {
    await db.downloadEvent.create({
      data: {
        type: input.type,
        platform: input.platform,
        success: input.success,
        errorCode: input.errorCode ?? null,
        durationMs: Math.max(0, Math.round(input.durationMs)),
        downloadId: input.downloadId ?? null,
      },
    });
  } catch {
    console.error("Failed to record event");
  }
}
