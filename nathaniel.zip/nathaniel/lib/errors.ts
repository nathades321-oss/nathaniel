export type ErrorCode =
  | "INVALID_URL"
  | "UNSUPPORTED_URL"
  | "PRIVATE_VIDEO"
  | "PLATFORM_RESTRICTED"
  | "PROVIDER_UNAVAILABLE"
  | "NETWORK_ERROR"
  | "RATE_LIMITED"
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "VALIDATION_ERROR"
  | "FILE_TOO_LARGE"
  | "EMAIL_TAKEN"
  | "INTERNAL_ERROR";

export const ERROR_MESSAGES: Record<ErrorCode, string> = {
  INVALID_URL: "Please enter a valid video URL.",
  UNSUPPORTED_URL: "Nathaniel doesn't support this platform yet.",
  PRIVATE_VIDEO: "This video isn't publicly accessible.",
  PLATFORM_RESTRICTED: "This platform doesn't provide a permitted download option for this video.",
  PROVIDER_UNAVAILABLE: "Nathaniel can't retrieve this video through the available platform integration.",
  NETWORK_ERROR: "Something went wrong while contacting the platform. Please try again.",
  RATE_LIMITED: "Too many requests. Please wait a moment and try again.",
  UNAUTHORIZED: "Please sign in to continue.",
  FORBIDDEN: "You don't have access to this.",
  NOT_FOUND: "We couldn't find what you asked for.",
  VALIDATION_ERROR: "Some of the information you sent isn't valid.",
  FILE_TOO_LARGE: "This file is larger than Nathaniel allows.",
  EMAIL_TAKEN: "An account with this email already exists.",
  INTERNAL_ERROR: "Something went wrong on our side. Please try again.",
};

export const ERROR_STATUS: Record<ErrorCode, number> = {
  INVALID_URL: 400,
  UNSUPPORTED_URL: 422,
  PRIVATE_VIDEO: 403,
  PLATFORM_RESTRICTED: 422,
  PROVIDER_UNAVAILABLE: 503,
  NETWORK_ERROR: 502,
  RATE_LIMITED: 429,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  VALIDATION_ERROR: 400,
  FILE_TOO_LARGE: 413,
  EMAIL_TAKEN: 409,
  INTERNAL_ERROR: 500,
};

export class AppError extends Error {
  readonly code: ErrorCode;
  readonly retryAfterSeconds?: number;

  constructor(code: ErrorCode, message?: string, options?: { retryAfterSeconds?: number }) {
    super(message ?? ERROR_MESSAGES[code]);
    this.name = "AppError";
    this.code = code;
    this.retryAfterSeconds = options?.retryAfterSeconds;
  }
}

export function isErrorCode(value: unknown): value is ErrorCode {
  return typeof value === "string" && value in ERROR_MESSAGES;
}
