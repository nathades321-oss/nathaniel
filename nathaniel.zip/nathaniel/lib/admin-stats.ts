import { db } from "@/lib/db";

export interface AdminStats {
  totalUsers: number;
  totalRequests: number;
  successful: number;
  failed: number;
  byPlatform: Array<{ platform: string; count: number }>;
  recent: Array<{ id: string; type: string; platform: string; success: boolean; errorCode: string | null; createdAt: Date }>;
}

export async function getAdminStats(): Promise<AdminStats> {
  const [totalUsers, totalRequests, successful, platformGroups, recent] = await Promise.all([
    db.user.count(),
    db.downloadEvent.count(),
    db.downloadEvent.count({ where: { success: true } }),
    db.downloadEvent.groupBy({ by: ["platform"], _count: { _all: true }, orderBy: { _count: { platform: "desc" } } }),
    db.downloadEvent.findMany({
      orderBy: { createdAt: "desc" },
      take: 10,
      select: { id: true, type: true, platform: true, success: true, errorCode: true, createdAt: true },
    }),
  ]);

  return {
    totalUsers,
    totalRequests,
    successful,
    failed: totalRequests - successful,
    byPlatform: platformGroups.map((group) => ({ platform: group.platform, count: group._count._all })),
    recent,
  };
}
