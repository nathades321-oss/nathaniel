import { z } from "zod";
import { BaseProvider } from "@/lib/providers/base";
import { fetchPlatformJson, httpsUrlOrNull } from "@/lib/providers/http";
import { ProviderError, type MediaInfo, type ProviderStatus } from "@/lib/providers/types";

const VIDEO_ID = /^[\w-]{11}$/;

const videosResponseSchema = z.object({
  items: z
    .array(
      z.object({
        snippet: z.object({
          title: z.string(),
          channelTitle: z.string().optional(),
          thumbnails: z.record(z.object({ url: z.string() })).optional(),
        }),
        contentDetails: z.object({ duration: z.string() }).optional(),
        status: z.object({ privacyStatus: z.string() }).optional(),
      }),
    )
    .default([]),
});

const THUMBNAIL_PREFERENCE = ["maxres", "standard", "high", "medium", "default"];

export function parseIsoDuration(value: string): number | null {
  const match = value.match(/^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$/);
  if (!match) return null;
  const [, days = "0", hours = "0", minutes = "0", seconds = "0"] = match;
  return Number(days) * 86_400 + Number(hours) * 3600 + Number(minutes) * 60 + Number(seconds);
}

export function extractYouTubeId(url: URL): string | null {
  const host = url.hostname.replace(/^www\./, "");
  let candidate: string | undefined;
  if (host === "youtu.be") {
    candidate = url.pathname.split("/")[1];
  } else if (url.pathname === "/watch") {
    candidate = url.searchParams.get("v") ?? undefined;
  } else {
    candidate = url.pathname.match(/^\/(?:shorts|live|embed)\/([^/?]+)/)?.[1];
  }
  return candidate && VIDEO_ID.test(candidate) ? candidate : null;
}

/** Uses the YouTube Data API v3, which exposes metadata but no downloadable files. */
export class YouTubeProvider extends BaseProvider {
  readonly name = "YouTube";
  readonly platform = "YOUTUBE" as const;
  readonly hosts = ["youtube.com", "youtu.be"] as const;

  protected matchesPath(url: URL): boolean {
    return extractYouTubeId(url) !== null;
  }

  getStatus(): ProviderStatus {
    return { configured: Boolean(process.env.YOUTUBE_API_KEY), requiredEnv: ["YOUTUBE_API_KEY"] };
  }

  async getMediaInfo(url: URL): Promise<MediaInfo> {
    const apiKey = process.env.YOUTUBE_API_KEY;
    const videoId = extractYouTubeId(url);
    if (!apiKey) throw new ProviderError("PROVIDER_UNAVAILABLE");
    if (!videoId) throw new ProviderError("INVALID_URL");

    const endpoint = new URL("https://www.googleapis.com/youtube/v3/videos");
    endpoint.searchParams.set("part", "snippet,contentDetails,status");
    endpoint.searchParams.set("id", videoId);
    endpoint.searchParams.set("key", apiKey);

    const parsed = videosResponseSchema.safeParse(
      await fetchPlatformJson(endpoint, { denied: "PROVIDER_UNAVAILABLE" }),
    );
    if (!parsed.success) throw new ProviderError("NETWORK_ERROR");

    const item = parsed.data.items[0];
    if (!item || item.status?.privacyStatus === "private") throw new ProviderError("PRIVATE_VIDEO");

    const thumbnails = item.snippet.thumbnails ?? {};
    const thumbnailKey = THUMBNAIL_PREFERENCE.find((key) => thumbnails[key]);
    return {
      platform: this.platform,
      sourceUrl: `https://www.youtube.com/watch?v=${videoId}`,
      title: item.snippet.title,
      author: item.snippet.channelTitle ?? null,
      thumbnailUrl: httpsUrlOrNull(thumbnailKey ? thumbnails[thumbnailKey]?.url : undefined),
      durationSeconds: item.contentDetails ? parseIsoDuration(item.contentDetails.duration) : null,
    };
  }
}
