import { config } from "@/lib/config";
import type { ErrorCode } from "@/lib/errors";
import { ProviderError } from "@/lib/providers/types";

interface FetchOptions {
  /** Error to raise for 400/401/403/404. Defaults to PRIVATE_VIDEO. */
  denied?: ErrorCode;
}

/**
 * Calls a fixed platform API endpoint. Callers build the URL from a constant
 * host, so user input only ever appears in query parameters.
 */
export async function fetchPlatformJson(endpoint: URL, options: FetchOptions = {}): Promise<unknown> {
  let response: Response;
  try {
    response = await fetch(endpoint, {
      headers: { Accept: "application/json", "User-Agent": "Nathaniel/1.0 (+permitted-downloads)" },
      signal: AbortSignal.timeout(config.requestTimeoutMs),
      redirect: "error",
      cache: "no-store",
    });
  } catch {
    throw new ProviderError("NETWORK_ERROR");
  }

  if (response.status === 429) throw new ProviderError("RATE_LIMITED");
  if ([400, 401, 403, 404].includes(response.status)) throw new ProviderError(options.denied ?? "PRIVATE_VIDEO");
  if (!response.ok) throw new ProviderError("NETWORK_ERROR");

  try {
    return await response.json();
  } catch {
    throw new ProviderError("NETWORK_ERROR");
  }
}

export function httpsUrlOrNull(value: string | undefined): string | null {
  if (!value) return null;
  try {
    const url = new URL(value);
    return url.protocol === "https:" ? url.toString() : null;
  } catch {
    return null;
  }
}
