import { z } from "zod";
import { hostMatches } from "@/lib/ssrf";
import { ProviderError, type DownloadOption, type MediaInfo, type Platform, type ProviderStatus, type VideoProvider } from "@/lib/providers/types";
import { fetchPlatformJson, httpsUrlOrNull } from "@/lib/providers/http";

export const oEmbedSchema = z
  .object({
    title: z.string().optional(),
    author_name: z.string().optional(),
    thumbnail_url: z.string().optional(),
    html: z.string().optional(),
  })
  .passthrough();

export type OEmbedResponse = z.infer<typeof oEmbedSchema>;

export abstract class BaseProvider implements VideoProvider {
  abstract readonly name: string;
  abstract readonly platform: Platform;
  abstract readonly hosts: readonly string[];
  readonly downloadHosts: readonly string[] = [];

  protected abstract matchesPath(url: URL): boolean;
  abstract getMediaInfo(url: URL): Promise<MediaInfo>;

  canHandle(url: URL): boolean {
    return hostMatches(url.hostname, this.hosts) && this.matchesPath(url);
  }

  /**
   * None of the platform APIs Nathaniel integrates with return a downloadable
   * file. A provider overrides this only when its platform documents one.
   */
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  async getDownloadOptions(media: MediaInfo): Promise<DownloadOption[]> {
    return [];
  }

  getStatus(): ProviderStatus {
    return { configured: true, requiredEnv: [] };
  }

  protected async fetchOEmbed(endpoint: URL): Promise<OEmbedResponse> {
    const parsed = oEmbedSchema.safeParse(await fetchPlatformJson(endpoint));
    if (!parsed.success) throw new ProviderError("NETWORK_ERROR");
    return parsed.data;
  }

  protected toMedia(sourceUrl: URL, data: OEmbedResponse, fallbackTitle: string): MediaInfo {
    return {
      platform: this.platform,
      sourceUrl: sourceUrl.toString(),
      title: (data.title ?? "").trim() || fallbackTitle,
      author: data.author_name?.trim() || null,
      thumbnailUrl: httpsUrlOrNull(data.thumbnail_url),
      durationSeconds: null,
    };
  }
}
