import { MetaProvider } from "@/lib/providers/meta";
import type { MediaInfo } from "@/lib/providers/types";

export class InstagramProvider extends MetaProvider {
  readonly name = "Instagram";
  readonly platform = "INSTAGRAM" as const;
  readonly hosts = ["instagram.com"] as const;
  protected readonly oEmbedPath = "instagram_oembed";

  protected matchesPath(url: URL): boolean {
    return /^\/(?:[\w.]+\/)?(?:p|reel|reels|tv)\/[\w-]+\/?$/.test(url.pathname);
  }

  async getMediaInfo(url: URL): Promise<MediaInfo> {
    const data = await this.fetchOEmbed(this.buildEndpoint(url));
    const fallback = data.author_name ? `Instagram post by ${data.author_name}` : "Instagram post";
    return this.toMedia(url, data, fallback);
  }
}
