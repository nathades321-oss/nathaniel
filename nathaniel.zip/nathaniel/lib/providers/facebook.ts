import { MetaProvider } from "@/lib/providers/meta";
import type { MediaInfo } from "@/lib/providers/types";

export class FacebookProvider extends MetaProvider {
  readonly name = "Facebook";
  readonly platform = "FACEBOOK" as const;
  readonly hosts = ["facebook.com", "fb.watch"] as const;
  protected readonly oEmbedPath = "oembed_video";

  protected matchesPath(url: URL): boolean {
    const { hostname, pathname, searchParams } = url;
    if (hostname === "fb.watch") return /^\/[\w-]+\/?$/.test(pathname);
    if (/^\/watch\/?$/.test(pathname)) return /^\d+$/.test(searchParams.get("v") ?? "");
    return /\/videos\/\d+/.test(pathname) || /^\/reel\/\d+/.test(pathname) || /^\/share\/[vr]\/[\w-]+/.test(pathname);
  }

  async getMediaInfo(url: URL): Promise<MediaInfo> {
    const data = await this.fetchOEmbed(this.buildEndpoint(url));
    const fallback = data.author_name ? `Facebook video by ${data.author_name}` : "Facebook video";
    return this.toMedia(url, data, fallback);
  }
}
