import { BaseProvider } from "@/lib/providers/base";
import { ProviderError, type ProviderStatus } from "@/lib/providers/types";

const REQUIRED_ENV = ["META_APP_ID", "META_CLIENT_TOKEN"];

/** Shared behaviour for Instagram and Facebook, which use Meta's oEmbed Read API. */
export abstract class MetaProvider extends BaseProvider {
  protected abstract readonly oEmbedPath: string;

  getStatus(): ProviderStatus {
    return { configured: REQUIRED_ENV.every((name) => Boolean(process.env[name])), requiredEnv: REQUIRED_ENV };
  }

  protected buildEndpoint(url: URL): URL {
    const appId = process.env.META_APP_ID;
    const clientToken = process.env.META_CLIENT_TOKEN;
    if (!appId || !clientToken) throw new ProviderError("PROVIDER_UNAVAILABLE");
    const endpoint = new URL(`https://graph.facebook.com/v21.0/${this.oEmbedPath}`);
    endpoint.searchParams.set("url", url.toString());
    endpoint.searchParams.set("access_token", `${appId}|${clientToken}`);
    return endpoint;
  }
}
