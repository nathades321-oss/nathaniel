import { AppError, type ErrorCode } from "@/lib/errors";
import type { DownloadOption, MediaInfo, Platform, ProviderStatus } from "@/types/media";

export type { DownloadOption, MediaInfo, Platform, ProviderStatus };

export interface VideoProvider {
  readonly name: string;
  readonly platform: Platform;
  /** Domains (and their subdomains) this provider recognises. */
  readonly hosts: readonly string[];
  /** Domains a file URL returned by this provider may be fetched from. */
  readonly downloadHosts: readonly string[];
  canHandle(url: URL): boolean;
  getMediaInfo(url: URL): Promise<MediaInfo>;
  getDownloadOptions(media: MediaInfo): Promise<DownloadOption[]>;
  getStatus(): ProviderStatus;
}

export type ProviderResult =
  | { ok: true; media: MediaInfo; options: DownloadOption[] }
  | { ok: false; error: { code: ErrorCode; message: string } };

export class ProviderError extends AppError {
  constructor(code: ErrorCode, message?: string) {
    super(code, message);
    this.name = "ProviderError";
  }
}
