import { hostMatches } from "@/lib/ssrf";
import { FacebookProvider } from "@/lib/providers/facebook";
import { InstagramProvider } from "@/lib/providers/instagram";
import { TikTokProvider } from "@/lib/providers/tiktok";
import { TwitterProvider } from "@/lib/providers/twitter";
import type { Platform, VideoProvider } from "@/lib/providers/types";
import { YouTubeProvider } from "@/lib/providers/youtube";

const providers: readonly VideoProvider[] = [
  new TikTokProvider(),
  new TwitterProvider(),
  new InstagramProvider(),
  new FacebookProvider(),
  new YouTubeProvider(),
];

export function listProviders(): readonly VideoProvider[] {
  return providers;
}

/** Identifies the platform from the domain alone, regardless of path. */
export function detectPlatform(url: URL): Platform | null {
  return providers.find((provider) => hostMatches(url.hostname, provider.hosts))?.platform ?? null;
}

/** Returns the provider that recognises both the domain and the video URL structure. */
export function findProvider(url: URL): VideoProvider | null {
  return providers.find((provider) => provider.canHandle(url)) ?? null;
}

export function getProviderByPlatform(platform: Platform): VideoProvider | null {
  return providers.find((provider) => provider.platform === platform) ?? null;
}
