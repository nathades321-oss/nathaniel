import { BaseProvider } from "@/lib/providers/base";
import type { MediaInfo } from "@/lib/providers/types";

/** Uses TikTok's public oEmbed endpoint, which returns metadata only. */
export class TikTokProvider extends BaseProvider {
  readonly name = "TikTok";
  readonly platform = "TIKTOK" as const;
  readonly hosts = ["tiktok.com"] as const;

  protected matchesPath(url: URL): boolean {
    if (url.hostname === "vm.tiktok.com" || url.hostname === "vt.tiktok.com") {
      return /^\/[A-Za-z0-9]+\/?$/.test(url.pathname);
    }
    return /^\/@[\w.-]+\/video\/\d+\/?$/.test(url.pathname);
  }

  async getMediaInfo(url: URL): Promise<MediaInfo> {
    const endpoint = new URL("https://www.tiktok.com/oembed");
    endpoint.searchParams.set("url", url.toString());
    const data = await this.fetchOEmbed(endpoint);
    return this.toMedia(url, data, "TikTok video");
  }
}
