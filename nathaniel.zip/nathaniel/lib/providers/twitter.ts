import { BaseProvider, type OEmbedResponse } from "@/lib/providers/base";
import type { MediaInfo } from "@/lib/providers/types";

const ENTITIES: Record<string, string> = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&#39;": "'" };

function postText(html: string | undefined): string | null {
  const paragraph = html?.match(/<p[^>]*>([\s\S]*?)<\/p>/i)?.[1];
  if (!paragraph) return null;
  const text = paragraph
    .replace(/<[^>]+>/g, "")
    .replace(/&(amp|lt|gt|quot|#39);/g, (entity) => ENTITIES[entity] ?? entity)
    .replace(/\s+/g, " ")
    .trim();
  return text ? (text.length > 120 ? `${text.slice(0, 117)}...` : text) : null;
}

/** Uses X's public oEmbed endpoint, which returns the post text and author only. */
export class TwitterProvider extends BaseProvider {
  readonly name = "X / Twitter";
  readonly platform = "TWITTER" as const;
  readonly hosts = ["twitter.com", "x.com"] as const;

  protected matchesPath(url: URL): boolean {
    return /^\/(?:i\/)?[\w]{1,15}\/status\/\d+(?:\/.*)?$/.test(url.pathname) || /^\/i\/status\/\d+/.test(url.pathname);
  }

  async getMediaInfo(url: URL): Promise<MediaInfo> {
    const endpoint = new URL("https://publish.twitter.com/oembed");
    endpoint.searchParams.set("url", url.toString());
    endpoint.searchParams.set("omit_script", "true");
    endpoint.searchParams.set("dnt", "true");
    const data: OEmbedResponse = await this.fetchOEmbed(endpoint);
    const author = data.author_name?.trim();
    const fallback = author ? `Post by ${author}` : "X post";
    return this.toMedia(url, { ...data, title: postText(data.html) ?? fallback }, fallback);
  }
}
