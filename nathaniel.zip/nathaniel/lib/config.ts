function positiveInt(name: string, fallback: number): number {
  const parsed = Number.parseInt(process.env[name] ?? "", 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

export const config = {
  get requestTimeoutMs(): number {
    return positiveInt("REQUEST_TIMEOUT_MS", 10_000);
  },
  get downloadTimeoutMs(): number {
    return positiveInt("DOWNLOAD_TIMEOUT_MS", 60_000);
  },
  get maxDownloadBytes(): number {
    return positiveInt("MAX_DOWNLOAD_BYTES", 100 * 1024 * 1024);
  },
  get appUrl(): string {
    return process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";
  },
};
