import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { AppError } from "@/lib/errors";

export interface SessionUser {
  id: string;
  role: "USER" | "ADMIN";
  name?: string | null;
  email?: string | null;
}

export async function getOptionalUser(): Promise<SessionUser | null> {
  const session = await auth();
  return session?.user?.id ? session.user : null;
}

/** For API routes: throws UNAUTHORIZED. */
export async function requireApiUser(): Promise<SessionUser> {
  const user = await getOptionalUser();
  if (!user) throw new AppError("UNAUTHORIZED");
  return user;
}

/** For pages: redirects to sign in. */
export async function requirePageUser(callbackPath: string): Promise<SessionUser> {
  const user = await getOptionalUser();
  if (!user) redirect(`/login?callbackUrl=${encodeURIComponent(callbackPath)}`);
  return user;
}

/** For the admin area: non-admins get a 404-style redirect home. */
export async function requireAdmin(): Promise<SessionUser> {
  const user = await requirePageUser("/admin");
  if (user.role !== "ADMIN") redirect("/");
  return user;
}
