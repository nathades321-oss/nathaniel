"use client";

import { useEffect, useRef, useState } from "react";
import { Info } from "lucide-react";
import { toast } from "sonner";
import { DownloadOptions } from "@/components/download-options";
import { LoadingState } from "@/components/loading-state";
import { UrlInput } from "@/components/url-input";
import { VideoCard } from "@/components/video-card";
import { ERROR_MESSAGES } from "@/lib/errors";
import { toFileName } from "@/lib/utils";
import type { AnalyzeData, ApiResponse } from "@/types/api";
import type { PublicDownloadOption } from "@/types/media";

async function readEnvelope<T>(response: Response): Promise<ApiResponse<T>> {
  try {
    return (await response.json()) as ApiResponse<T>;
  } catch {
    return { success: false, error: { code: "NETWORK_ERROR", message: ERROR_MESSAGES.NETWORK_ERROR } };
  }
}

export function DownloadClient({ initialUrl = "" }: { initialUrl?: string }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalyzeData | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [submittedUrl, setSubmittedUrl] = useState("");

  const autoRan = useRef(false);

  async function analyze(url: string) {
    setError(null);
    setResult(null);
    if (!url.trim()) {
      setError(ERROR_MESSAGES.INVALID_URL);
      return;
    }
    setLoading(true);
    try {
      const response = await fetch("/api/video/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      const envelope = await readEnvelope<AnalyzeData>(response);
      if (envelope.success) {
        setResult(envelope.data);
        setSubmittedUrl(url.trim());
      } else {
        setError(envelope.error.message);
      }
    } catch {
      setError(ERROR_MESSAGES.NETWORK_ERROR);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (initialUrl && !autoRan.current) {
      autoRan.current = true;
      void analyze(initialUrl);
    }
    // Runs once for a link handed over from the homepage.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function download(option: PublicDownloadOption) {
    if (!result) return;
    setBusyId(option.id);
    try {
      const response = await fetch("/api/video/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: submittedUrl, optionId: option.id, downloadId: result.downloadId ?? undefined }),
      });
      if (!response.ok) {
        const envelope = await readEnvelope<never>(response);
        toast.error(envelope.success ? ERROR_MESSAGES.NETWORK_ERROR : envelope.error.message);
        return;
      }
      const blob = await response.blob();
      const href = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = href;
      link.download = toFileName(result.media.title, option.format);
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(href);
      toast.success("Download started");
    } catch {
      toast.error(ERROR_MESSAGES.NETWORK_ERROR);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-6">
      <UrlInput onSubmit={analyze} loading={loading} error={error} initialValue={initialUrl} />
      {loading ? <LoadingState /> : null}
      {result ? (
        <VideoCard media={result.media}>
          {result.options.length > 0 ? (
            <DownloadOptions options={result.options} busyId={busyId} onDownload={download} />
          ) : (
            <div role="status" className="flex gap-3 rounded-lg bg-muted p-3 text-sm">
              <Info aria-hidden="true" className="mt-0.5 h-5 w-5 shrink-0" />
              <p>{result.notice ?? ERROR_MESSAGES.PLATFORM_RESTRICTED}</p>
            </div>
          )}
        </VideoCard>
      ) : null}
    </div>
  );
}
