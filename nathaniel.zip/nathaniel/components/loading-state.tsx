import { Skeleton } from "@/components/ui/skeleton";

export function LoadingState() {
  return (
    <div role="status" aria-live="polite" className="rounded-2xl border bg-card p-4 sm:p-6">
      <p className="mb-4 text-sm font-medium text-muted-foreground">Analyzing your link...</p>
      <div className="flex flex-col gap-4 sm:flex-row">
        <Skeleton className="aspect-video w-full sm:w-64" />
        <div className="flex-1 space-y-3">
          <Skeleton className="h-6 w-3/4" />
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="h-4 w-1/4" />
          <Skeleton className="h-11 w-full" />
        </div>
      </div>
    </div>
  );
}
