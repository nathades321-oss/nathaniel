"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { signOut } from "next-auth/react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ERROR_MESSAGES } from "@/lib/errors";
import type { ApiResponse } from "@/types/api";

export function SettingsForm({ name, email }: { name: string; email: string }) {
  const router = useRouter();
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextName = String(new FormData(event.currentTarget).get("name") ?? "");
    setPending(true);
    setError(null);
    try {
      const response = await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: nextName }),
      });
      const envelope = (await response.json()) as ApiResponse<{ name: string }>;
      if (!envelope.success) {
        setError(envelope.error.message);
        return;
      }
      toast.success("Saved");
      router.refresh();
    } catch {
      setError(ERROR_MESSAGES.NETWORK_ERROR);
    } finally {
      setPending(false);
    }
  }

  async function deleteAccount() {
    if (!window.confirm("Delete your account and all download history? This can't be undone.")) return;
    const response = await fetch("/api/settings", { method: "DELETE" });
    if (!response.ok) {
      toast.error(ERROR_MESSAGES.INTERNAL_ERROR);
      return;
    }
    await signOut({ redirectTo: "/" });
  }

  return (
    <div className="space-y-10">
      <form onSubmit={save} className="space-y-4" noValidate>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" value={email} readOnly disabled />
        </div>
        <div>
          <Label htmlFor="name">Name</Label>
          <Input id="name" name="name" defaultValue={name} autoComplete="name" required />
        </div>
        <p role="alert" className="min-h-5 text-sm font-medium text-destructive">{error}</p>
        <Button type="submit" disabled={pending}>Save changes</Button>
      </form>
      <section aria-labelledby="danger" className="rounded-2xl border border-destructive/40 p-5">
        <h2 id="danger" className="font-display text-lg font-bold">Delete account</h2>
        <p className="mt-1 text-sm text-muted-foreground">Removes your account and your download history.</p>
        <Button variant="destructive" className="mt-4" onClick={deleteAccount}>Delete account</Button>
      </section>
    </div>
  );
}
