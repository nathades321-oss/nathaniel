"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Trash2 } from "lucide-react";
import { toast } from "sonner";
import { PlatformIcon } from "@/components/platform-icons";
import { Button } from "@/components/ui/button";
import { ERROR_MESSAGES } from "@/lib/errors";
import { platformLabel, PLATFORMS } from "@/lib/platforms";
import type { HistoryEntry } from "@/types/api";
import type { Platform } from "@/types/media";

const STATUS_LABELS: Record<HistoryEntry["status"], string> = {
  AVAILABLE: "Ready",
  UNAVAILABLE: "No download offered",
  DOWNLOADED: "Downloaded",
  FAILED: "Failed",
};

export function HistoryList({ entries }: { entries: HistoryEntry[] }) {
  const router = useRouter();
  const [removing, setRemoving] = useState<string | null>(null);
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const visible = entries.filter((entry) => !hidden.has(entry.id));

  async function remove(id: string) {
    setRemoving(id);
    try {
      const response = await fetch(`/api/history/${encodeURIComponent(id)}`, { method: "DELETE" });
      if (!response.ok) throw new Error("failed");
      setHidden((previous) => new Set(previous).add(id));
      toast.success("Removed from history");
      router.refresh();
    } catch {
      toast.error(ERROR_MESSAGES.INTERNAL_ERROR);
    } finally {
      setRemoving(null);
    }
  }

  if (visible.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed p-10 text-center">
        <p className="font-display text-xl font-bold">You haven&apos;t downloaded anything yet.</p>
        <p className="mt-2 text-muted-foreground">Paste a video link on the download page to get started.</p>
        <Button asChild className="mt-5">
          <a href="/download">Go to download</a>
        </Button>
      </div>
    );
  }

  return (
    <ul className="space-y-3">
      {visible.map((entry) => (
        <li key={entry.id} className="flex gap-3 rounded-2xl border bg-card p-3 sm:gap-4 sm:p-4">
          <div className="grid h-16 w-24 shrink-0 place-items-center overflow-hidden rounded-lg bg-muted sm:h-20 sm:w-32">
            {entry.thumbnailUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={entry.thumbnailUrl} alt="" referrerPolicy="no-referrer" loading="lazy" className="h-full w-full object-cover" />
            ) : (PLATFORMS as readonly string[]).includes(entry.platform) ? (
              <PlatformIcon platform={entry.platform as Platform} className="h-6 w-6 text-muted-foreground" />
            ) : null}
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="truncate font-semibold">{entry.title}</h3>
            <p className="truncate text-sm text-muted-foreground">{entry.sourceUrl}</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {platformLabel(entry.platform)} &middot; {STATUS_LABELS[entry.status]} &middot;{" "}
              <time dateTime={entry.createdAt}>{new Date(entry.createdAt).toLocaleDateString(undefined, { dateStyle: "medium" })}</time>
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            aria-label={`Remove ${entry.title} from history`}
            disabled={removing === entry.id}
            onClick={() => remove(entry.id)}
          >
            <Trash2 aria-hidden="true" className="h-5 w-5" />
          </Button>
        </li>
      ))}
    </ul>
  );
}
