"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { signIn } from "next-auth/react";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ERROR_MESSAGES } from "@/lib/errors";
import type { ApiResponse } from "@/types/api";

interface AuthFormProps {
  mode: "login" | "register";
  callbackUrl?: string;
}

function safeCallback(value: string | undefined): string {
  return value && value.startsWith("/") && !value.startsWith("//") ? value : "/download";
}

export function AuthForm({ mode, callbackUrl }: AuthFormProps) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  const isRegister = mode === "register";

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const email = String(form.get("email") ?? "");
    const password = String(form.get("password") ?? "");
    setError(null);
    setPending(true);
    try {
      if (isRegister) {
        const response = await fetch("/api/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: String(form.get("name") ?? ""), email, password }),
        });
        const envelope = (await response.json()) as ApiResponse<{ id: string }>;
        if (!envelope.success) {
          setError(envelope.error.message);
          return;
        }
      }
      const result = await signIn("credentials", { email, password, redirect: false });
      if (!result || result.error) {
        setError("Email or password is incorrect.");
        return;
      }
      router.push(safeCallback(callbackUrl));
      router.refresh();
    } catch {
      setError(ERROR_MESSAGES.NETWORK_ERROR);
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4" noValidate>
      {isRegister ? (
        <div>
          <Label htmlFor="name">Name</Label>
          <Input id="name" name="name" autoComplete="name" required />
        </div>
      ) : null}
      <div>
        <Label htmlFor="email">Email</Label>
        <Input id="email" name="email" type="email" autoComplete="email" required />
      </div>
      <div>
        <Label htmlFor="password">Password</Label>
        <Input
          id="password"
          name="password"
          type="password"
          autoComplete={isRegister ? "new-password" : "current-password"}
          aria-describedby={isRegister ? "password-hint" : undefined}
          required
        />
        {isRegister ? (
          <p id="password-hint" className="mt-1.5 text-sm text-muted-foreground">
            At least 10 characters, with a letter and a number.
          </p>
        ) : null}
      </div>
      <p role="alert" className="min-h-5 text-sm font-medium text-destructive">
        {error}
      </p>
      <Button type="submit" size="lg" className="w-full" disabled={pending}>
        {pending ? <Loader2 aria-hidden="true" className="h-5 w-5 animate-spin" /> : null}
        {isRegister ? "Create account" : "Sign in"}
      </Button>
      <p className="text-center text-sm text-muted-foreground">
        {isRegister ? "Already have an account? " : "New to Nathaniel? "}
        <Link href={isRegister ? "/login" : "/register"} className="font-semibold text-foreground underline underline-offset-4">
          {isRegister ? "Sign in" : "Create an account"}
        </Link>
      </p>
    </form>
  );
}
