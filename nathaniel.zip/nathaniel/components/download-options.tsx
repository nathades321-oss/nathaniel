"use client";

import { Download, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatBytes } from "@/lib/utils";
import type { PublicDownloadOption } from "@/types/media";

interface DownloadOptionsProps {
  options: PublicDownloadOption[];
  busyId: string | null;
  onDownload: (option: PublicDownloadOption) => void;
}

export function DownloadOptions({ options, busyId, onDownload }: DownloadOptionsProps) {
  return (
    <table className="w-full text-left text-sm">
      <caption className="sr-only">Available download formats</caption>
      <thead className="text-muted-foreground">
        <tr>
          <th scope="col" className="pb-2 font-medium">Quality</th>
          <th scope="col" className="pb-2 font-medium">Format</th>
          <th scope="col" className="pb-2 font-medium">Size</th>
          <th scope="col" className="pb-2"><span className="sr-only">Action</span></th>
        </tr>
      </thead>
      <tbody>
        {options.map((option) => {
          const busy = busyId === option.id;
          return (
            <tr key={option.id} className="border-t">
              <td className="py-3 font-semibold">{option.quality}</td>
              <td className="py-3">{option.format.toUpperCase()}</td>
              <td className="py-3">{formatBytes(option.sizeBytes)}</td>
              <td className="py-3 text-right">
                <Button
                  size="sm"
                  disabled={busyId !== null}
                  onClick={() => onDownload(option)}
                  aria-label={`Download ${option.quality} ${option.format.toUpperCase()}`}
                >
                  {busy ? <Loader2 aria-hidden="true" className="h-4 w-4 animate-spin" /> : <Download aria-hidden="true" className="h-4 w-4" />}
                  Download
                </Button>
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}
