import { Facebook, Instagram, Twitter, Youtube, type LucideProps } from "lucide-react";
import type { Platform } from "@/types/media";

function TikTokIcon(props: LucideProps) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" width={props.size ?? 24} height={props.size ?? 24} {...props}>
      <path d="M14 3v11.5a3.5 3.5 0 1 1-3.5-3.5" />
      <path d="M14 3c.4 2.6 2 4.2 5 4.4" />
    </svg>
  );
}

const ICONS: Record<Platform, (props: LucideProps) => React.JSX.Element> = {
  TIKTOK: TikTokIcon,
  TWITTER: (props) => <Twitter {...props} />,
  INSTAGRAM: (props) => <Instagram {...props} />,
  FACEBOOK: (props) => <Facebook {...props} />,
  YOUTUBE: (props) => <Youtube {...props} />,
};

export function PlatformIcon({ platform, ...props }: { platform: Platform } & LucideProps) {
  const Icon = ICONS[platform];
  return <Icon aria-hidden="true" {...props} />;
}
