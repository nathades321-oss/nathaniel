import { Clock, User } from "lucide-react";
import { PlatformIcon } from "@/components/platform-icons";
import { formatDuration } from "@/lib/utils";
import { platformLabel } from "@/lib/platforms";
import type { MediaInfo } from "@/types/media";

export function VideoCard({ media, children }: { media: MediaInfo; children: React.ReactNode }) {
  const duration = formatDuration(media.durationSeconds);
  return (
    <article className="overflow-hidden rounded-2xl border bg-card">
      <div className="flex flex-col sm:flex-row">
        <div className="relative aspect-video w-full shrink-0 bg-muted sm:w-72">
          {media.thumbnailUrl ? (
            // Thumbnails come from platform CDNs with changing hosts, so next/image is not used here.
            // eslint-disable-next-line @next/next/no-img-element
            <img src={media.thumbnailUrl} alt="" referrerPolicy="no-referrer" className="h-full w-full object-cover" />
          ) : (
            <div className="grid h-full place-items-center text-muted-foreground">
              <PlatformIcon platform={media.platform} className="h-10 w-10" />
            </div>
          )}
        </div>
        <div className="flex-1 p-4 sm:p-5">
          <h2 className="font-display text-xl font-bold leading-snug">{media.title}</h2>
          <dl className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <dt className="sr-only">Platform</dt>
              <dd className="flex items-center gap-1.5">
                <PlatformIcon platform={media.platform} className="h-4 w-4" />
                {platformLabel(media.platform)}
              </dd>
            </div>
            {media.author ? (
              <div className="flex items-center gap-1.5">
                <dt className="sr-only">Author</dt>
                <dd className="flex items-center gap-1.5"><User aria-hidden="true" className="h-4 w-4" />{media.author}</dd>
              </div>
            ) : null}
            {duration ? (
              <div className="flex items-center gap-1.5">
                <dt className="sr-only">Duration</dt>
                <dd className="flex items-center gap-1.5"><Clock aria-hidden="true" className="h-4 w-4" />{duration}</dd>
              </div>
            ) : null}
          </dl>
        </div>
      </div>
      <div className="border-t p-4 sm:px-5">{children}</div>
    </article>
  );
}
