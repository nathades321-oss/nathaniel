import Link from "next/link";

export function Brand({ className }: { className?: string }) {
  return (
    <Link href="/" className={`inline-flex items-center gap-2.5 rounded-md font-display text-xl font-bold tracking-tight ${className ?? ""}`}>
      <span aria-hidden="true" className="grid h-8 w-8 place-items-center rounded-lg bg-primary font-display text-lg text-primary-foreground">
        N
      </span>
      Nathaniel
    </Link>
  );
}
