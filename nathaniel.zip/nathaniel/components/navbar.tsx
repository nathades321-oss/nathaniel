import Link from "next/link";
import { signOut } from "@/lib/auth";
import { getOptionalUser } from "@/lib/session";
import { Brand } from "@/components/brand";
import { NavLinks, type NavItem } from "@/components/nav-links";
import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";

export async function Navbar() {
  const user = await getOptionalUser();

  const items: NavItem[] = user
    ? [
        { href: "/", label: "Home" },
        { href: "/download", label: "Download" },
        { href: "/history", label: "History" },
        ...(user.role === "ADMIN" ? [{ href: "/admin", label: "Admin" }] : []),
      ]
    : [
        { href: "/", label: "Home" },
        { href: "/download", label: "Download" },
        { href: "/history", label: "History" },
        { href: "/about", label: "About" },
      ];

  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
        <Brand />
        <nav aria-label="Main" className="hidden items-center gap-1 md:flex">
          <NavLinks items={items} />
        </nav>
        <div className="flex items-center gap-1">
          <ThemeToggle />
          {user ? (
            <>
              <Button asChild variant="outline" size="sm">
                <Link href="/settings">Account</Link>
              </Button>
              <form
                action={async () => {
                  "use server";
                  await signOut({ redirectTo: "/" });
                }}
              >
                <Button type="submit" variant="ghost" size="sm">
                  Sign out
                </Button>
              </form>
            </>
          ) : (
            <Button asChild size="sm">
              <Link href="/login">Sign in</Link>
            </Button>
          )}
        </div>
      </div>
      <nav aria-label="Main (mobile)" className="flex gap-1 overflow-x-auto border-t px-4 py-1.5 md:hidden">
        <NavLinks items={items} className="shrink-0" />
      </nav>
    </header>
  );
}
