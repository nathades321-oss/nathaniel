"use client";

import { useId, useState } from "react";
import { Link2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface UrlInputProps {
  onSubmit: (url: string) => void;
  loading: boolean;
  error: string | null;
  initialValue?: string;
}

export function UrlInput({ onSubmit, loading, error, initialValue = "" }: UrlInputProps) {
  const [value, setValue] = useState(initialValue);
  const inputId = useId();
  const errorId = `${inputId}-error`;

  return (
    <form
      noValidate
      onSubmit={(event) => {
        event.preventDefault();
        onSubmit(value);
      }}
      className="w-full"
    >
      <label htmlFor={inputId} className="sr-only">
        Video URL
      </label>
      <div className="flex flex-col gap-2 rounded-2xl border-2 border-foreground/80 bg-card p-2 shadow-[4px_4px_0_0_hsl(var(--foreground)/0.85)] sm:flex-row">
        <div className="relative flex-1">
          <Link2 aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
          <input
            id={inputId}
            type="url"
            inputMode="url"
            autoComplete="off"
            autoCapitalize="off"
            spellCheck={false}
            placeholder="Paste video URL..."
            value={value}
            onChange={(event) => setValue(event.target.value)}
            aria-invalid={error ? true : undefined}
            aria-describedby={error ? errorId : undefined}
            className="h-12 w-full rounded-xl bg-transparent pl-10 pr-3 text-base placeholder:text-muted-foreground focus-visible:ring-offset-0"
          />
        </div>
        <Button type="submit" size="lg" disabled={loading} className="sm:min-w-36">
          {loading ? <Loader2 aria-hidden="true" className="h-5 w-5 animate-spin" /> : null}
          {loading ? "Analyzing" : "Get video"}
        </Button>
      </div>
      <p id={errorId} role="alert" className="mt-3 min-h-5 text-sm font-medium text-destructive">
        {error}
      </p>
    </form>
  );
}
