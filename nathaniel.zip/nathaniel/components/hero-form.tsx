"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { UrlInput } from "@/components/url-input";
import { ERROR_MESSAGES } from "@/lib/errors";

export function HeroForm() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);

  return (
    <UrlInput
      loading={false}
      error={error}
      onSubmit={(url) => {
        if (!url.trim()) {
          setError(ERROR_MESSAGES.INVALID_URL);
          return;
        }
        router.push(`/download?url=${encodeURIComponent(url.trim())}`);
      }}
    />
  );
}
