# Nathaniel

Nathaniel lets people paste a link to a public social-media video and retrieve the download options **the platform itself permits**. It never bypasses DRM, logins, private settings, paywalls, rate limits, or other access controls.

## What works today (read this first)

Every integration uses an official, documented endpoint:

| Platform | Mechanism | Credentials | Returns a file? |
| --- | --- | --- | --- |
| TikTok | public oEmbed | none | No, metadata only |
| X / Twitter | public oEmbed | none | No, metadata only |
| Instagram | Meta oEmbed Read API | `META_APP_ID`, `META_CLIENT_TOKEN` | No, metadata only |
| Facebook | Meta oEmbed Read API | `META_APP_ID`, `META_CLIENT_TOKEN` | No, metadata only |
| YouTube | YouTube Data API v3 | `YOUTUBE_API_KEY` | No, metadata only |

None of these APIs hand out a downloadable video file. So out of the box Nathaniel shows the title, author, thumbnail and duration, then tells the user: "This platform doesn't provide a permitted download option for this video."

The download pipeline (option picker, server-side re-resolution, SSRF checks, size limit, streaming, history status) is fully implemented and tested. It activates for any provider that returns `DownloadOption`s from `getDownloadOptions`. Add one only where a platform documents a permitted file (for example an API granting the owner export rights). Do not add scrapers or unofficial extractors.

## Features

- Provider architecture (`VideoProvider`) with one module per platform
- Zod validation, strict domain and path allowlists, SSRF protection (literal IP, private range, metadata endpoint, DNS-resolution checks)
- Rate limiting (in-memory, or Upstash Redis for serverless), request timeouts, download size limit
- Auth.js credentials login, protected `/history` and `/settings`, admin-only `/admin`
- Download history with per-user authorization and deletion
- Operational events that store no URLs, IPs, or user identifiers
- Light and dark mode, mobile-first layout, keyboard and screen reader support
- Secure headers (CSP, HSTS, frame denial), consistent JSON API envelope
- 101 unit and integration tests

## Stack

Next.js 15 (App Router), React 19, TypeScript (strict), Tailwind CSS 3, Lucide, PostgreSQL, Prisma 6, Auth.js v5 (beta), Zod, Vitest.

## Prerequisites

- Node.js 20 or newer
- A PostgreSQL database

## Installation

```bash
npm install
cp .env.example .env
```

## Environment variables

See `.env.example`. Required: `DATABASE_URL`, `AUTH_SECRET`, `NEXT_PUBLIC_APP_URL`, `AUTH_URL`. Provider credentials are optional and each one enables its provider. Secrets are read only on the server and never reach client JavaScript.

## Database setup

```bash
npm run db:migrate -- --name init   # development: creates and applies the migration
npm run db:deploy                   # production: applies committed migrations
```

Create the first admin:

```bash
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='a-long-password-1' npm run db:seed
```

## Development

```bash
npm run dev         # http://localhost:3000
npm run lint
npm run typecheck
npm run test
```

## Production build

```bash
npm run build
npm run start
```

## Deployment (Vercel)

1. Push the repository and import it in Vercel.
2. Add a Postgres database (Vercel Postgres, Neon, or Supabase) and set `DATABASE_URL`.
3. Set `AUTH_SECRET`, `NEXT_PUBLIC_APP_URL`, `AUTH_URL`, and any provider credentials.
4. Add Upstash Redis and set `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN`. Without it, rate limits are per serverless instance and therefore weak.
5. Run `npm run db:deploy` against the production database (locally with the production URL, or in CI).
6. Deploy. `vercel.json` raises the download route to a 60 second duration. Vercel limits response sizes on serverless functions, so keep `MAX_DOWNLOAD_BYTES` within your plan's limit.

## Platform API configuration

- **YouTube**: create an API key in Google Cloud Console, enable YouTube Data API v3, set `YOUTUBE_API_KEY`.
- **Instagram and Facebook**: create a Meta app, add the oEmbed Read feature, set `META_APP_ID` and the app's client token as `META_CLIENT_TOKEN`. Meta may require app review.
- **TikTok and X**: no credentials. Their oEmbed endpoints are public.

## Security considerations

- User URLs are parsed, forced to HTTPS, and matched against per-provider host and path rules. The server never fetches a user-supplied host. Platform API calls go to fixed hosts with the link passed only as a query parameter.
- File URLs come from providers only, never from the client. The client sends an option id, the server re-resolves the video, then checks the file host against the provider's allowlist and verifies every DNS answer is public before fetching. Redirects are refused.
- Downloads are streamed with a hard byte limit and timeout.
- Passwords are hashed with bcrypt. Sessions are JWTs, and the role is re-read from the database on each request so demotions take effect immediately.
- API errors never include stack traces or internal messages.
- The in-memory rate limiter resets when the process restarts. Use Upstash in production.
- Review `/privacy` and `/terms` with a lawyer before launch. They are starting points.
