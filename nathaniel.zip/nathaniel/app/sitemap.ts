import type { MetadataRoute } from "next";
import { config } from "@/lib/config";

export default function sitemap(): MetadataRoute.Sitemap {
  return ["", "/download", "/about", "/privacy", "/terms"].map((path) => ({ url: `${config.appUrl}${path}` }));
}
