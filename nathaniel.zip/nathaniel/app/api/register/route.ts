import bcrypt from "bcryptjs";
import { Prisma } from "@prisma/client";
import { ok, parseJson, withErrorHandling } from "@/lib/api";
import { db } from "@/lib/db";
import { AppError } from "@/lib/errors";
import { enforceRateLimit } from "@/lib/rate-limit";
import { registerSchema } from "@/lib/validation";

export const runtime = "nodejs";

export function POST(request: Request): Promise<Response> {
  return withErrorHandling(async () => {
    await enforceRateLimit(request, "register", null, { limit: 5, windowSeconds: 60 * 60 });
    const { name, email, password } = await parseJson(request, registerSchema);
    const passwordHash = await bcrypt.hash(password, 12);
    try {
      const user = await db.user.create({ data: { name, email, passwordHash }, select: { id: true } });
      return ok({ id: user.id }, { status: 201 });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
        throw new AppError("EMAIL_TAKEN");
      }
      throw error;
    }
  });
}
