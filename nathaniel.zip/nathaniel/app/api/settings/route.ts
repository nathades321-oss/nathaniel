import { ok, parseJson, withErrorHandling } from "@/lib/api";
import { db } from "@/lib/db";
import { requireApiUser } from "@/lib/session";
import { settingsSchema } from "@/lib/validation";

export const runtime = "nodejs";

export function PATCH(request: Request): Promise<Response> {
  return withErrorHandling(async () => {
    const user = await requireApiUser();
    const { name } = await parseJson(request, settingsSchema);
    await db.user.update({ where: { id: user.id }, data: { name } });
    return ok({ name });
  });
}

export function DELETE(): Promise<Response> {
  return withErrorHandling(async () => {
    const user = await requireApiUser();
    await db.user.delete({ where: { id: user.id } });
    return ok({ deleted: true });
  });
}
