import { parseJson, withErrorHandling } from "@/lib/api";
import { config } from "@/lib/config";
import { AppError } from "@/lib/errors";
import { recordEvent } from "@/lib/events";
import { markDownloadStatus } from "@/lib/history";
import { enforceRateLimit } from "@/lib/rate-limit";
import { getOptionalUser } from "@/lib/session";
import { downloadRequestSchema } from "@/lib/validation";
import { assertDownloadUrlAllowed, resolveVideo } from "@/lib/video-service";
import { toFileName } from "@/lib/utils";

export const runtime = "nodejs";
export const maxDuration = 60;

/** Streams the file to the client while enforcing the configured size limit. */
function limitedStream(source: ReadableStream<Uint8Array>, maxBytes: number, onFinish: (ok: boolean) => void): ReadableStream<Uint8Array> {
  const reader = source.getReader();
  let received = 0;
  return new ReadableStream<Uint8Array>({
    async pull(controller) {
      try {
        const { done, value } = await reader.read();
        if (done) {
          controller.close();
          onFinish(true);
          return;
        }
        received += value.byteLength;
        if (received > maxBytes) {
          await reader.cancel();
          controller.error(new AppError("FILE_TOO_LARGE"));
          onFinish(false);
          return;
        }
        controller.enqueue(value);
      } catch (error) {
        controller.error(error);
        onFinish(false);
      }
    },
    cancel(reason) {
      onFinish(false);
      return reader.cancel(reason);
    },
  });
}

export function POST(request: Request): Promise<Response> {
  return withErrorHandling(async () => {
    const user = await getOptionalUser();
    await enforceRateLimit(request, "download", user?.id, { limit: user ? 10 : 5, windowSeconds: 60 });
    const { url, optionId, downloadId } = await parseJson(request, downloadRequestSchema);

    const startedAt = Date.now();
    // Re-resolve on the server. The client only chooses an option id, never a file URL.
    const { provider, media, options } = await resolveVideo(url);
    const option = options.find((candidate) => candidate.id === optionId);
    if (!option) throw new AppError("PLATFORM_RESTRICTED");

    const fileUrl = await assertDownloadUrlAllowed(provider, option);

    let upstream: Response;
    try {
      upstream = await fetch(fileUrl, {
        signal: AbortSignal.timeout(config.downloadTimeoutMs),
        redirect: "error",
        cache: "no-store",
      });
    } catch {
      throw new AppError("NETWORK_ERROR");
    }
    if (!upstream.ok || !upstream.body) throw new AppError("NETWORK_ERROR");

    const declaredLength = Number(upstream.headers.get("content-length") ?? "0");
    if (declaredLength > config.maxDownloadBytes) throw new AppError("FILE_TOO_LARGE");

    const finish = (success: boolean) => {
      void recordEvent({
        type: "DOWNLOAD",
        platform: media.platform,
        success,
        errorCode: success ? null : "NETWORK_ERROR",
        durationMs: Date.now() - startedAt,
        downloadId: user ? (downloadId ?? null) : null,
      });
      if (user && downloadId) void markDownloadStatus(user.id, downloadId, success ? "DOWNLOADED" : "FAILED");
    };

    const headers = new Headers({
      "Content-Type": option.mimeType,
      "Content-Disposition": `attachment; filename="${toFileName(media.title, option.format)}"`,
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
    });
    if (declaredLength > 0) headers.set("Content-Length", String(declaredLength));

    return new Response(limitedStream(upstream.body, config.maxDownloadBytes, finish), { headers });
  });
}
