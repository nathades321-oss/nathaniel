import { ok, parseJson, withErrorHandling } from "@/lib/api";
import { db } from "@/lib/db";
import { AppError } from "@/lib/errors";
import { recordEvent } from "@/lib/events";
import { detectPlatform } from "@/lib/providers/registry";
import { enforceRateLimit } from "@/lib/rate-limit";
import { getOptionalUser } from "@/lib/session";
import { analyzeRequestSchema } from "@/lib/validation";
import { resolveVideo, toPublicOption } from "@/lib/video-service";
import type { AnalyzeData } from "@/types/api";

export const runtime = "nodejs";

export function POST(request: Request): Promise<Response> {
  return withErrorHandling(async () => {
    const user = await getOptionalUser();
    await enforceRateLimit(request, "analyze", user?.id, { limit: user ? 30 : 10, windowSeconds: 60 });
    const { url } = await parseJson(request, analyzeRequestSchema);

    const startedAt = Date.now();
    const platform = detectPlatform(url) ?? "UNKNOWN";
    try {
      const { media, options } = await resolveVideo(url);

      let downloadId: string | null = null;
      if (user) {
        const record = await db.download.create({
          data: {
            userId: user.id,
            sourceUrl: media.sourceUrl,
            platform: media.platform,
            title: media.title,
            thumbnailUrl: media.thumbnailUrl,
            status: options.length > 0 ? "AVAILABLE" : "UNAVAILABLE",
          },
          select: { id: true },
        });
        downloadId = record.id;
      }

      await recordEvent({ type: "ANALYZE", platform, success: true, durationMs: Date.now() - startedAt, downloadId });

      const data: AnalyzeData = {
        media,
        options: options.map(toPublicOption),
        downloadId,
        notice: options.length === 0 ? new AppError("PLATFORM_RESTRICTED").message : null,
      };
      return ok(data);
    } catch (error) {
      const errorCode = error instanceof AppError ? error.code : "INTERNAL_ERROR";
      await recordEvent({ type: "ANALYZE", platform, success: false, errorCode, durationMs: Date.now() - startedAt });
      throw error;
    }
  });
}
