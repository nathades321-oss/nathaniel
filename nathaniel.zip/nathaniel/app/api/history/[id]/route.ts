import { ok, withErrorHandling } from "@/lib/api";
import { deleteHistoryEntry } from "@/lib/history";
import { requireApiUser } from "@/lib/session";
import { historyIdSchema } from "@/lib/validation";

export const runtime = "nodejs";

export function DELETE(_request: Request, context: { params: Promise<{ id: string }> }): Promise<Response> {
  return withErrorHandling(async () => {
    const user = await requireApiUser();
    const id = historyIdSchema.parse((await context.params).id);
    await deleteHistoryEntry(user.id, id);
    return ok({ deleted: true });
  });
}
