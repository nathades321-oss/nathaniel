import { ok, withErrorHandling } from "@/lib/api";
import { listHistory } from "@/lib/history";
import { requireApiUser } from "@/lib/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export function GET(): Promise<Response> {
  return withErrorHandling(async () => {
    const user = await requireApiUser();
    return ok(await listHistory(user.id));
  });
}
