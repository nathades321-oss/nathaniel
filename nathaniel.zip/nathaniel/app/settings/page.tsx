import type { Metadata } from "next";
import { PageShell } from "@/components/page-shell";
import { SettingsForm } from "@/components/settings-form";
import { db } from "@/lib/db";
import { requirePageUser } from "@/lib/session";

export const metadata: Metadata = { title: "Account settings", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const sessionUser = await requirePageUser("/settings");
  const user = await db.user.findUnique({ where: { id: sessionUser.id }, select: { name: true, email: true } });
  return (
    <div className="mx-auto max-w-xl">
      <PageShell title="Account">
        <SettingsForm name={user?.name ?? ""} email={user?.email ?? ""} />
      </PageShell>
    </div>
  );
}
