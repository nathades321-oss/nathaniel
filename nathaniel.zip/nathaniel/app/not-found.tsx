import Link from "next/link";
import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <PageShell title="Page not found" intro="The page you asked for doesn't exist or has moved.">
      <Button asChild>
        <Link href="/">Back to home</Link>
      </Button>
    </PageShell>
  );
}
