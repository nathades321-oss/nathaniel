import type { Metadata } from "next";
import { PageShell, Prose } from "@/components/page-shell";

export const metadata: Metadata = { title: "Terms of service", description: "The rules for using Nathaniel." };

export default function TermsPage() {
  return (
    <PageShell title="Terms of service">
      <Prose>
        <p>This page describes the defaults of this software. The operator of your deployment should review and adapt it.</p>
        <h2>Acceptable use</h2>
        <ul>
          <li>Use Nathaniel only for content you own, have permission to save, or that the platform explicitly allows you to download.</li>
          <li>Do not attempt to bypass platform protections, automate abusive request volumes, or probe the service.</li>
          <li>Follow the terms of each platform whose content you access.</li>
        </ul>
        <h2>Availability</h2>
        <p>Platforms control what they expose. Nathaniel may be unable to provide a file for any given video, and the service is provided as is.</p>
        <h2>Accounts</h2>
        <p>You are responsible for your account. Accounts used for abuse may be removed.</p>
      </Prose>
    </PageShell>
  );
}
