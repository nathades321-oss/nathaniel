import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth-form";
import { PageShell } from "@/components/page-shell";
import { getOptionalUser } from "@/lib/session";

export const metadata: Metadata = { title: "Sign in", robots: { index: false } };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ callbackUrl?: string }> }) {
  if (await getOptionalUser()) redirect("/download");
  const { callbackUrl } = await searchParams;
  return (
    <div className="mx-auto max-w-md">
      <PageShell title="Sign in">
        <AuthForm mode="login" callbackUrl={callbackUrl} />
      </PageShell>
    </div>
  );
}
