import type { Metadata } from "next";
import { DownloadClient } from "@/components/download-client";
import { PageShell } from "@/components/page-shell";

export const metadata: Metadata = {
  title: "Download",
  description: "Paste a supported video link to see the download options the platform permits.",
};

export default async function DownloadPage({ searchParams }: { searchParams: Promise<{ url?: string | string[] }> }) {
  const { url } = await searchParams;
  const initialUrl = typeof url === "string" ? url : "";
  return (
    <PageShell title="Download a video" intro="Paste the link of a public video. Nathaniel shows what the platform allows you to save.">
      <DownloadClient initialUrl={initialUrl} />
    </PageShell>
  );
}
