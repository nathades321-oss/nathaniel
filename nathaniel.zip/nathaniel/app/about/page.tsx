import type { Metadata } from "next";
import { PageShell, Prose } from "@/components/page-shell";

export const metadata: Metadata = {
  title: "About",
  description: "What Nathaniel does, which platforms it supports, and what it refuses to do.",
};

export default function AboutPage() {
  return (
    <PageShell title="About Nathaniel" intro="A download helper that works inside the rules each platform sets.">
      <Prose>
        <p>
          Nathaniel takes a link to a public video, asks the platform through its official API what it can share, and
          shows you the result. If the platform offers a file, you can save it. If it does not, Nathaniel says so.
        </p>
        <h2>What it will not do</h2>
        <ul>
          <li>Bypass DRM, logins, private settings, or paywalls.</li>
          <li>Work around rate limits or other access controls.</li>
          <li>Fetch arbitrary addresses. Only recognised video links are accepted.</li>
        </ul>
        <h2>Your responsibility</h2>
        <p>Only save content you own, have permission to save, or that the platform explicitly lets you download.</p>
      </Prose>
    </PageShell>
  );
}
