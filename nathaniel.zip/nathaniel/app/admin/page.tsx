import type { Metadata } from "next";
import { PageShell } from "@/components/page-shell";
import { getAdminStats } from "@/lib/admin-stats";
import { platformLabel } from "@/lib/platforms";
import { listProviders } from "@/lib/providers/registry";
import { requireAdmin } from "@/lib/session";

export const metadata: Metadata = { title: "Admin", robots: { index: false } };
export const dynamic = "force-dynamic";

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border bg-card p-4">
      <dt className="text-sm text-muted-foreground">{label}</dt>
      <dd className="mt-1 font-display text-3xl font-bold tabular-nums">{value.toLocaleString()}</dd>
    </div>
  );
}

export default async function AdminPage() {
  await requireAdmin();
  const stats = await getAdminStats();
  const peak = Math.max(1, ...stats.byPlatform.map((row) => row.count));
  const providers = listProviders().map((provider) => ({ name: provider.name, status: provider.getStatus() }));

  return (
    <div className="mx-auto max-w-5xl">
      <PageShell title="Admin">
        <dl className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat label="Users" value={stats.totalUsers} />
          <Stat label="Requests" value={stats.totalRequests} />
          <Stat label="Successful" value={stats.successful} />
          <Stat label="Failed" value={stats.failed} />
        </dl>

        <div className="mt-8 grid gap-8 lg:grid-cols-2">
          <section aria-labelledby="by-platform">
            <h2 id="by-platform" className="font-display text-xl font-bold">Requests by platform</h2>
            {stats.byPlatform.length === 0 ? (
              <p className="mt-3 text-muted-foreground">No requests yet.</p>
            ) : (
              <ul className="mt-4 space-y-3">
                {stats.byPlatform.map((row) => (
                  <li key={row.platform}>
                    <div className="flex justify-between text-sm">
                      <span>{platformLabel(row.platform)}</span>
                      <span className="tabular-nums">{row.count}</span>
                    </div>
                    <div className="mt-1 h-2 rounded-full bg-muted" role="img" aria-label={`${row.count} requests`}>
                      <div className="h-2 rounded-full bg-primary" style={{ width: `${(row.count / peak) * 100}%` }} />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section aria-labelledby="providers">
            <h2 id="providers" className="font-display text-xl font-bold">Provider status</h2>
            <ul className="mt-4 divide-y rounded-2xl border bg-card">
              {providers.map(({ name, status }) => (
                <li key={name} className="flex items-center justify-between gap-3 p-3 text-sm">
                  <span className="font-medium">{name}</span>
                  <span className={status.configured ? "text-foreground" : "text-destructive"}>
                    {status.configured ? "Configured" : `Missing ${status.requiredEnv.join(", ")}`}
                  </span>
                </li>
              ))}
            </ul>
          </section>
        </div>

        <section aria-labelledby="recent" className="mt-8">
          <h2 id="recent" className="font-display text-xl font-bold">Recent activity</h2>
          {stats.recent.length === 0 ? (
            <p className="mt-3 text-muted-foreground">No activity yet.</p>
          ) : (
            <div className="mt-4 overflow-x-auto rounded-2xl border bg-card">
              <table className="w-full text-left text-sm">
                <thead className="text-muted-foreground">
                  <tr>
                    <th scope="col" className="p-3 font-medium">When</th>
                    <th scope="col" className="p-3 font-medium">Type</th>
                    <th scope="col" className="p-3 font-medium">Platform</th>
                    <th scope="col" className="p-3 font-medium">Result</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.recent.map((event) => (
                    <tr key={event.id} className="border-t">
                      <td className="p-3"><time dateTime={event.createdAt.toISOString()}>{event.createdAt.toLocaleString()}</time></td>
                      <td className="p-3">{event.type === "ANALYZE" ? "Analyze" : "Download"}</td>
                      <td className="p-3">{platformLabel(event.platform)}</td>
                      <td className="p-3">{event.success ? "Success" : (event.errorCode ?? "Failed")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </PageShell>
    </div>
  );
}
