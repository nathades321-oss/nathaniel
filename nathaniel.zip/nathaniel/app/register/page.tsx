import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AuthForm } from "@/components/auth-form";
import { PageShell } from "@/components/page-shell";
import { getOptionalUser } from "@/lib/session";

export const metadata: Metadata = { title: "Create account", robots: { index: false } };

export default async function RegisterPage() {
  if (await getOptionalUser()) redirect("/download");
  return (
    <div className="mx-auto max-w-md">
      <PageShell title="Create your account" intro="Keep a history of the links you have checked.">
        <AuthForm mode="register" />
      </PageShell>
    </div>
  );
}
