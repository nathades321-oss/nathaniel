import type { Metadata } from "next";
import { PageShell, Prose } from "@/components/page-shell";

export const metadata: Metadata = { title: "Privacy policy", description: "How Nathaniel handles your data." };

export default function PrivacyPage() {
  return (
    <PageShell title="Privacy policy">
      <Prose>
        <p>This page describes the defaults of this software. The operator of your deployment should review and adapt it.</p>
        <h2>What we store</h2>
        <ul>
          <li>Account details you provide: name, email, and a salted password hash.</li>
          <li>Download history for signed-in users: link, platform, title, thumbnail, status, and date.</li>
          <li>Operational events: platform, outcome, error code, and duration. These hold no links, IP addresses, or user identifiers.</li>
        </ul>
        <h2>What we do with it</h2>
        <p>History is shown only to you. Events are used to monitor reliability and abuse. Nothing is sold or shared for advertising.</p>
        <h2>Rate limiting</h2>
        <p>To prevent abuse, request counts are kept briefly against a hashed identifier.</p>
        <h2>Your choices</h2>
        <p>You can remove history entries at any time and delete your account from the account page, which removes your history.</p>
      </Prose>
    </PageShell>
  );
}
