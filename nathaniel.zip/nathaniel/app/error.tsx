"use client";

import { PageShell } from "@/components/page-shell";
import { Button } from "@/components/ui/button";

export default function ErrorPage({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <PageShell title="Something went wrong" intro="The page failed to load. Try again in a moment.">
      <Button onClick={reset}>Try again</Button>
    </PageShell>
  );
}
