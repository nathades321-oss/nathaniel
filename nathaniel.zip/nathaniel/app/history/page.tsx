import type { Metadata } from "next";
import { HistoryList } from "@/components/history-list";
import { PageShell } from "@/components/page-shell";
import { listHistory } from "@/lib/history";
import { requirePageUser } from "@/lib/session";

export const metadata: Metadata = { title: "History", robots: { index: false } };
export const dynamic = "force-dynamic";

export default async function HistoryPage() {
  const user = await requirePageUser("/history");
  const entries = await listHistory(user.id);
  return (
    <PageShell title="Your history">
      <HistoryList entries={entries} />
    </PageShell>
  );
}
