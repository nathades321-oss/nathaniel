import { Ban, FileCheck2, Link2, ShieldCheck } from "lucide-react";
import { HeroForm } from "@/components/hero-form";
import { PlatformIcon } from "@/components/platform-icons";
import { PLATFORMS, PLATFORM_LABELS } from "@/lib/platforms";

const flow = [
  { icon: Link2, title: "Paste a link", text: "Nathaniel checks the address and works out which platform it belongs to." },
  { icon: ShieldCheck, title: "We ask the platform", text: "Only official, documented APIs are used. Nothing is scraped or unlocked." },
  { icon: FileCheck2, title: "You get what is permitted", text: "If the platform offers a file, you can pick a format and save it." },
];

export default function HomePage() {
  return (
    <>
      <section className="mx-auto max-w-6xl px-4 pb-14 pt-12 sm:pb-20 sm:pt-20">
        <div className="relative max-w-3xl">
          <div
            aria-hidden="true"
            className="absolute -top-6 right-0 hidden animate-stamp rounded-md border-2 border-accent px-3 py-1 font-display text-sm font-bold text-accent sm:block"
            style={{ transform: "rotate(-4deg)" }}
          >
            Permitted saves only
          </div>
          <h1 className="font-display text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-6xl">
            Download videos you have permission to save.
          </h1>
          <p className="mt-5 max-w-xl text-lg text-muted-foreground">
            Paste a supported video link and Nathaniel will find the available download options.
          </p>
          <div className="mt-8">
            <HeroForm />
          </div>
          <ul aria-label="Supported platforms" className="mt-2 flex flex-wrap gap-x-5 gap-y-2 text-sm text-muted-foreground">
            {PLATFORMS.map((platform) => (
              <li key={platform} className="flex items-center gap-2">
                <PlatformIcon platform={platform} className="h-4 w-4" />
                {PLATFORM_LABELS[platform]}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section aria-labelledby="how" className="border-y bg-muted/50">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 md:grid-cols-[1fr_2fr]">
          <h2 id="how" className="font-display text-3xl font-bold tracking-tight">How a link becomes a file</h2>
          <ol className="grid gap-6 sm:grid-cols-3">
            {flow.map(({ icon: Icon, title, text }) => (
              <li key={title}>
                <Icon aria-hidden="true" className="h-6 w-6" />
                <h3 className="mt-3 font-display text-lg font-bold">{title}</h3>
                <p className="mt-1 text-muted-foreground">{text}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section aria-labelledby="limits" className="mx-auto max-w-6xl px-4 py-14">
        <div className="flex max-w-3xl gap-4">
          <Ban aria-hidden="true" className="mt-1 h-6 w-6 shrink-0" />
          <div>
            <h2 id="limits" className="font-display text-2xl font-bold">Some videos will not have a download</h2>
            <p className="mt-2 text-muted-foreground">
              Most platforms share details about a public video but no file. When that happens, Nathaniel tells you so
              and stops. It never bypasses DRM, logins, private settings, paywalls, or rate limits.
            </p>
          </div>
        </div>
      </section>
    </>
  );
}
